// Web Audio API Synthesizers for Voice Udhaar App

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Case A Success Sound:
 * Joyful, affirmative two-tone or three-tone ascending chord (C5 -> E5 -> G5)
 */
export function playSuccessChime() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + index * 0.1);

      gain.gain.setValueAtTime(0, now + index * 0.1);
      gain.gain.linearRampToValueAtTime(0.25, now + index * 0.1 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + index * 0.1 + 0.45);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + index * 0.1);
      osc.stop(now + index * 0.1 + 0.5);
    });
  } catch (err) {
    console.warn('Audio play failed:', err);
  }
}

/**
 * Case B Error/Alert Beep:
 * Dissonant double-beep alert warning (300Hz sawtooth / square)
 */
export function playErrorAlert() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const beeps = [0, 0.18];
    beeps.forEach((startTime) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(280, now + startTime);
      osc.frequency.exponentialRampToValueAtTime(200, now + startTime + 0.12);

      gain.gain.setValueAtTime(0, now + startTime);
      gain.gain.linearRampToValueAtTime(0.35, now + startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + startTime + 0.14);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + startTime);
      osc.stop(now + startTime + 0.15);
    });
  } catch (err) {
    console.warn('Alert audio failed:', err);
  }
}

export const playAlertSound = playErrorAlert;
export const playSuccessSound = playSuccessChime;

/**
 * Soft tactile click for keyboard / keypad
 */
export function playClickSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(450, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.04);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.05);
  } catch (e) {
    // Ignore muted audio
  }
}

/**
 * Mic Start recording chime
 */
export function playVoiceStartSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.16);
  } catch (e) {
    // Ignore
  }
}

/**
 * Mic Stop recording sound
 */
export function playVoiceStopSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(700, now);
    osc.frequency.exponentialRampToValueAtTime(350, now + 0.12);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.13);
  } catch (e) {
    // Ignore
  }
}
