import {
  Customer,
  FinancialTab,
  FinancialVoiceOutput,
  KhataVoiceOutput,
  IntelligentVoiceParserResult,
  VoiceParserTab,
} from '../types';
import { parseUrduNumber, parseUrduNumberText, urduNumberDict, normalizeUrdu, URDU_NAME_MAPPINGS, parseEnglishNumberText, englishNumberDict } from './urduParser';
import { dbService } from '../services/db';

export { parseUrduNumberText, urduNumberDict, parseEnglishNumberText, englishNumberDict };

// Map Urdu, Arabic, and Devanagari digits to Latin digits
const DIGIT_MAP: Record<string, string> = {
  // Urdu / Arabic
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  // Devanagari (Hindi)
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
};

// Comprehensive multilingual lookup dictionary for Hindi, Urdu, and English
const MULTI_LANG_NUM_WORDS: Record<string, number> = {
  // Urdu numerals (1-100)
  'ایک': 1, 'دو': 2, 'تین': 3, 'چار': 4, 'پانچ': 5, 'چھ': 6, 'چہ': 6, 'چھے': 6, 'سات': 7, 'آٹھ': 8, 'اٹھ': 8, 'نو': 9, 'دس': 10,
  'گیارہ': 11, 'بارہ': 12, 'تیرہ': 13, 'چودہ': 14, 'پندرہ': 15, 'سولہ': 16,
  'سترہ': 17, 'اٹھارہ': 18, 'اٹہارہ': 18, 'انیس': 19, 'بیس': 20,
  'اکیس': 21, 'بائیس': 22, 'بائس': 22, 'تیئیس': 23, 'تئیس': 23, 'چوبیس': 24, 'پچیس': 25, 'چھبیس': 26, 'ستائیس': 27, 'ستائس': 27,
  'اٹھائیس': 28, 'اٹائیس': 28, 'انتیس': 29, 'تیس': 30,
  'اکتیس': 31, 'بتیس': 32, 'تینتیس': 33, 'چونتیس': 34, 'پینتیس': 35, 'چھتیس': 36, 'سینتیس': 37, 'اڑتیس': 38, 'انتالیس': 39, 'چالیس': 40,
  'اکتالیس': 41, 'بیالیس': 42, 'تینتالیس': 43, 'چوالیس': 44, 'پینتالیس': 45, 'چھیالیس': 46, 'سینتالیس': 47, 'اڑتالیس': 48, 'انچاس': 49, 'پچاس': 50,
  'اکیاون': 51, 'باون': 52, 'ترپن': 53, 'چوّن': 54, 'چون': 54, 'پچپن': 55, 'چھپن': 56, 'ستاون': 57, 'اٹھاون': 58, 'انسٹھ': 59, 'ساٹھ': 60,
  'اکسٹھ': 61, 'باسٹھ': 62, 'تریسٹھ': 63, 'چونسٹھ': 64, 'پینسٹھ': 65, 'چھیاسٹھ': 66, 'سڑسٹھ': 67, 'اڑسٹھ': 68, 'انہتر': 69, 'ستر': 70,
  'اکہتر': 71, 'بہتر': 72, 'تہتر': 73, 'چوہتر': 74, 'پچہتر': 75, 'چھہتر': 76, 'ستتر': 77, 'اٹھہتر': 78, 'اناسی': 79, 'اسی': 80,
  'اکیاسی': 81, 'بیاسی': 82, 'تراسی': 83, 'چوراسی': 84, 'پچاسی': 85, 'چھیاسی': 86, 'ستاسی': 87, 'اٹھاسی': 88, 'نواسی': 89, 'نوے': 90,
  'اکانوے': 91, 'بانوے': 92, 'ترانوے': 93, 'چورانوے': 94, 'پچانوے': 95, 'چھیانوے': 96, 'ستانوے': 97, 'اٹھانوے': 98, 'ننانوے': 99,
  'سو': 100,

  // Hindi (Devanagari 1-100)
  'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4, 'पांच': 5, 'पाँच': 5, 'छह': 6, 'छः': 6, 'सात': 7, 'आठ': 8, 'नौ': 9, 'दस': 10,
  'ग्यारह': 11, 'बारह': 12, 'तेरह': 13, 'चौदह': 14, 'पंद्रह': 15, 'सोलह': 16, 'सत्रह': 17, 'अठारह': 18, 'उन्नीस': 19, 'बीस': 20,
  'इक्कीस': 21, 'बाईस': 22, 'तेईस': 23, 'चौबीस': 24, 'पच्चीस': 25, 'छब्बीस': 26, 'सत्ताईस': 27, 'अट्ठाईस': 28, 'उनतीस': 29, 'तीस': 30,
  'इकत्तीस': 31, 'बत्तीस': 32, 'तैंतीस': 33, 'चौंतीस': 34, 'पैंतीस': 35, 'छत्तीस': 36, 'सैंतीस': 37, 'अड़तीस': 38, 'उनतालीस': 39, 'चालीस': 40,
  'इकतालीस': 41, 'बयालीस': 42, 'तैंतालीस': 43, 'चवालीस': 44, 'पैंतालीस': 45, 'छियालीस': 46, 'सैंतालीस': 47, 'अड़तालीस': 48, 'उनचास': 49, 'पचास': 50,
  'इक्यावन': 51, 'बावन': 52, 'तिरपन': 53, 'चौवन': 54, 'पचपन': 55, 'छप्पन': 56, 'सत्तावन': 57, 'अट्ठावन': 58, 'उनसठ': 59, 'साठ': 60,
  'इकसठ': 61, 'बासठ': 62, 'तिरसठ': 63, 'चौंसठ': 64, 'पैंसठ': 65, 'छियासठ': 66, 'सरसठ': 67, 'अड़सठ': 68, 'उनहत्तर': 69, 'सत्तर': 70,
  'इकहत्तर': 71, 'बहत्तर': 72, 'तिहत्तर': 73, 'चौहत्तर': 74, 'पचहत्तर': 75, 'छिहत्तर': 76, 'सतहत्तर': 77, 'अठहत्तर': 78, 'उन्नासी': 79, 'अस्सी': 80,
  'इक्यासी': 81, 'बयासी': 82, 'तिरासी': 83, 'चौरासी': 84, 'पचासी': 85, 'छियासी': 86, 'सत्तासी': 87, 'अट्ठासी': 88, 'नवासी': 89, 'नब्बे': 90,
  'इक्यानवे': 91, 'बानवे': 92, 'तिरानवे': 93, 'चौरानवे': 94, 'पंचानवे': 95, 'छियानवे': 96, 'सत्तानवे': 97, 'अट्ठानवे': 98, 'निन्यानवे': 99,
  'सौ': 100,

  // English & Roman Urdu
  'one': 1, 'ek': 1, 'two': 2, 'do': 2, 'three': 3, 'teen': 3, 'four': 4, 'char': 4, 'five': 5, 'panch': 5,
  'six': 6, 'che': 6, 'chay': 6, 'seven': 7, 'saat': 7, 'eight': 8, 'aath': 8, 'nine': 9, 'nau': 9, 'ten': 10, 'das': 10,
  'eleven': 11, 'gyarah': 11, 'twelve': 12, 'barah': 12, 'thirteen': 13, 'terah': 13, 'fourteen': 14, 'chaudah': 14,
  'fifteen': 15, 'pandrah': 15, 'sixteen': 16, 'solah': 16, 'seventeen': 17, 'satrah': 17, 'eighteen': 18, 'atharah': 18,
  'nineteen': 19, 'unnees': 19, 'twenty': 20, 'bees': 20,
  'twenty one': 21, 'twenty two': 22, 'twenty three': 23, 'twenty four': 24, 'twenty five': 25, 'pachees': 25,
  'twenty six': 26, 'twenty seven': 27, 'twenty eight': 28, 'twenty nine': 29, 'thirty': 30, 'tees': 30,
  'forty': 40, 'chalis': 40, 'fifty': 50, 'pachas': 50,
  'fifty one': 51, 'fifty two': 52, 'bawan': 52, 'baawan': 52, 'fifty three': 53, 'fifty four': 54, 'fifty five': 55, 'pachpan': 55,
  'sixty': 60, 'saath': 60, 'seventy': 70, 'sattar': 70, 'eighty': 80, 'assi': 80, 'ninety': 90, 'nawwe': 90,
  'hundred': 100, 'sau': 100,
};

function escapeRegExp(string: string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function parseNumberFactor(p: string): number | null {
  const clean = p.trim();
  if (!clean) return null;
  const d = clean.match(/\d+(?:\.\d+)?/);
  if (d) return parseFloat(d[0]);

  const sortedKeys = Object.keys(MULTI_LANG_NUM_WORDS).sort((a, b) => b.length - a.length);
  for (const k of sortedKeys) {
    const rx = new RegExp(`(?:^|[^\\p{L}\\p{N}])${escapeRegExp(k)}(?=[^\\p{L}\\p{N}]|$)`, 'iu');
    if (rx.test(clean)) {
      return MULTI_LANG_NUM_WORDS[k];
    }
  }
  return null;
}

/**
 * SECTION 4: EXACT LARGE & MIXED NUMBER SPEECH NORMALIZATION
 * Strict No-Rounding Rule: Do NOT round off or truncate spoken numbers.
 * Handles South Asian and International formats with 100% precision:
 * - "10,220", "10220" -> 10220
 * - "दस हजार दो सौ बीस" -> 10220
 * - "دس ہزار دو سو بیس" -> 10220
 * - "10 thousand 2 hundred 20" -> 10220
 * - "10,230" -> 10230, "1,252" -> 1252, "55" -> 55, "52" -> 52, "53" -> 53
 * - "1,55,000", "1,52,000" -> 155000, 152000
 * - "ایک لاکھ پچپن ہزار", "एक लाख पचपन हजार" -> 155000
 * - "ایک لاکھ باون ہزار", "एक लाख बावन हजार" -> 152000
 * - "1.55 lakh", "1.52 lakh", "1.55 لاکھ", "1.52 لاکھ" -> 155000, 152000
 * - "2 کروڑ 50 لاکھ" -> 25000000
 * - "50 ہزار 500" -> 50500
 * - Mixed arithmetic additions / subtractions
 */
export function normalizeNumberFromSpoken(text: string): number {
  if (!text) return 0;

  // 00. Dynamic Learning & User Voice Corrections Lookup (Auto-lookup before default dictionary / AI)
  try {
    const correction = dbService.findVoiceCorrection(text);
    if (correction && correction.corrected_number > 0) {
      return correction.corrected_number;
    }
  } catch {
    // Ignore fallback
  }

  // 0. Direct exact Urdu/Roman-Urdu Number Text Parser (local offline parser)
  const exactUrduParsed = parseUrduNumberText(text);
  if (exactUrduParsed > 0) {
    return exactUrduParsed;
  }

  // 0b. Direct exact English Spoken Number Parser (local offline parser)
  const exactEnglishParsed = parseEnglishNumberText(text);
  if (exactEnglishParsed > 0) {
    return exactEnglishParsed;
  }

  let raw = text.trim();

  // 1. Normalize all Urdu, Arabic, and Devanagari digits to Latin digits
  for (const [u, d] of Object.entries(DIGIT_MAP)) {
    raw = raw.split(u).join(d);
  }

  // Pre-normalize specific Urdu letter variants
  let s = raw
    .toLowerCase()
    .replace(/\u06be/g, 'ہ')
    .replace(/\u06d2/g, 'ی')
    .replace(/[\u064B-\u065F\u0670]/g, '');

  // 2. Exact comma-formatted numbers (e.g. 1,55,000, 1,52,000, 10,220, 10,230, 1,252, 12,50,000)
  const commaMatches = s.match(/\b\d{1,3}(?:,\d{2,3})+(?:\.\d+)?\b/g);
  if (commaMatches && commaMatches.length > 0) {
    const cleanCommaStr = commaMatches[0].replace(/,/g, '');
    const commaNum = parseFloat(cleanCommaStr);

    const afterComma = s.replace(commaMatches[0], '').trim();
    if (afterComma && (afterComma.includes('aur') || afterComma.includes('اور') || afterComma.includes('+') || afterComma.includes('جمع') || afterComma.includes('और'))) {
      const restDigits = afterComma.match(/\b\d+(?:\.\d+)?\b/);
      if (restDigits) {
        return commaNum + parseFloat(restDigits[0]);
      }
    }
    if (afterComma && (afterComma.includes('minus') || afterComma.includes('منہا') || afterComma.includes('-') || afterComma.includes('تفریق') || afterComma.includes('घटा'))) {
      const restDigits = afterComma.match(/\b\d+(?:\.\d+)?\b/);
      if (restDigits) {
        return Math.max(0, commaNum - parseFloat(restDigits[0]));
      }
    }

    if (!/لاکھ|لاکہ|लाख|lakh|lac|کروڑ|करोड़|crore|ہزار|हजार|हज़ार|hazar/i.test(afterComma)) {
      return commaNum;
    }
  }

  // 3. Decimal + Unit (e.g. "1.55 lakh", "1.52 lakh", "1.55 لاکھ", "1.52 لاکھ")
  const decimalUnitMatch = s.match(/(\d+\.\d+)\s*(لاکھ|لاکہ|लाख|lakh|lac|کروڑ|करोड़|crore|ہزار|हजार|हज़ार|hazar|thousand|k)/iu);
  if (decimalUnitMatch) {
    const val = parseFloat(decimalUnitMatch[1]);
    const unit = decimalUnitMatch[2];
    let mult = 1000;
    if (/کروڑ|करोड़|crore/i.test(unit)) mult = 10000000;
    else if (/لاکھ|لاکہ|लाख|lakh|lac/i.test(unit)) mult = 100000;
    else if (/ہزار|हजार|हज़ार|hazar|thousand|k/i.test(unit)) mult = 1000;
    return Math.round(val * mult);
  }

  // 4. Dedh (1.5x) / Dhai (2.5x)
  if (/ڈیڑھ|ڈیڑہ|डेढ़|dedh/i.test(s)) {
    if (/کروڑ|करोड़|crore/i.test(s)) return 15000000;
    if (/لاکھ|لاکہ|लाख|lakh|lac/i.test(s)) return 150000;
    if (/ہزار|हजार|हज़ार|hazar|thousand/i.test(s)) return 1500;
    if (/سو|सौ|sau|hundred/i.test(s)) return 150;
    return 1.5;
  }
  if (/ڈھائی|ڈہائی|ढाई|dhai/i.test(s)) {
    if (/کروڑ|करोड़|crore/i.test(s)) return 25000000;
    if (/لاکھ|لاکہ|लाख|lakh|lac/i.test(s)) return 250000;
    if (/ہزار|हजार|हज़ार|hazar|thousand/i.test(s)) return 2500;
    if (/سو|सौ|sau|hundred/i.test(s)) return 250;
    return 2.5;
  }

  // 5. Saadhe (+0.5) / Paune (-0.25)
  const saadheMatch = s.match(/(?:ساڑھے|ساڑہی|साढ़े|saadhe|sadhe)\s*([^\s]+)(?:\s*([^\s]+))?/iu);
  if (saadheMatch) {
    const numWord = saadheMatch[1];
    const unitWord = saadheMatch[2] || s;
    const baseNum = MULTI_LANG_NUM_WORDS[numWord] ?? (parseFloat(numWord) || null);
    if (baseNum) {
      let mult = 1000;
      if (/کروڑ|करोड़|crore/i.test(unitWord)) mult = 10000000;
      else if (/لاکھ|لاکہ|लाख|lakh|lac/i.test(unitWord)) mult = 100000;
      else if (/سو|सौ|sau|hundred/i.test(unitWord)) mult = 100;
      return Math.round((baseNum + 0.5) * mult);
    }
  }

  const pauneMatch = s.match(/(?:پونے|پونی|पौने|paune|pone)\s*([^\s]+)(?:\s*([^\s]+))?/iu);
  if (pauneMatch) {
    const numWord = pauneMatch[1];
    const unitWord = pauneMatch[2] || s;
    const baseNum = MULTI_LANG_NUM_WORDS[numWord] ?? (parseFloat(numWord) || null);
    if (baseNum) {
      let mult = 1000;
      if (/کروڑ|करोड़|crore/i.test(unitWord)) mult = 10000000;
      else if (/لاکھ|لاکہ|लाख|lakh|lac/i.test(unitWord)) mult = 100000;
      else if (/سو|सौ|sau|hundred/i.test(unitWord)) mult = 100;
      return Math.round((baseNum - 0.25) * mult);
    }
  }

  // 6. COMPOUND MULTIPLIERS (Crore + Lakh + Thousand + Hundred + Remainder)
  let totalCompound = 0;
  let hasScaleMatched = false;
  let workingText = s;

  // Crore
  const croreRegex = /(?:(\d+(?:\.\d+)?|[^\s]+(?:\s+[^\s]+)?)\s*(?:کروڑ|करोड़|crore))/iu;
  const croreMatch = workingText.match(croreRegex);
  if (croreMatch) {
    const factor = parseNumberFactor(croreMatch[1]) ?? 1;
    totalCompound += factor * 10000000;
    hasScaleMatched = true;
    workingText = workingText.replace(croreMatch[0], ' ');
  }

  // Lakh
  const lakhRegex = /(?:(\d+(?:\.\d+)?|[^\s]+(?:\s+[^\s]+)?)\s*(?:لاکھ|لاکہ|लाख|lakh|lac))/iu;
  const lakhMatch = workingText.match(lakhRegex);
  if (lakhMatch) {
    const factor = parseNumberFactor(lakhMatch[1]) ?? 1;
    totalCompound += factor * 100000;
    hasScaleMatched = true;
    workingText = workingText.replace(lakhMatch[0], ' ');
  }

  // Thousand
  const thousandRegex = /(?:(\d+(?:\.\d+)?|[^\s]+(?:\s+[^\s]+)?)\s*(?:ہزار|हजार|हज़ार|hazar|thousand|\bk\b))/iu;
  const thousandMatch = workingText.match(thousandRegex);
  if (thousandMatch) {
    const factor = parseNumberFactor(thousandMatch[1]) ?? 1;
    totalCompound += factor * 1000;
    hasScaleMatched = true;
    workingText = workingText.replace(thousandMatch[0], ' ');
  }

  // Hundred
  const hundredRegex = /(?:(\d+(?:\.\d+)?|[^\s]+(?:\s+[^\s]+)?)\s*(?:سو|सौ|sau|hundred))/iu;
  const hundredMatch = workingText.match(hundredRegex);
  if (hundredMatch) {
    const factor = parseNumberFactor(hundredMatch[1]) ?? 1;
    totalCompound += factor * 100;
    hasScaleMatched = true;
    workingText = workingText.replace(hundredMatch[0], ' ');
  }

  if (hasScaleMatched) {
    const cleanRemainder = workingText
      .replace(/روپے|روپیہ|روپئے|रुपये|रुपया|rupees|pkr|inr|rs|کو|سے|کا|کی|کے|دیے|لیے|وصول|ہوا|اور|and|aur|और|को|से|का|की|के|दिया|मिला/giu, ' ')
      .trim();

    const trailingDigitMatch = cleanRemainder.match(/\b\d+(?:\.\d+)?\b/);
    if (trailingDigitMatch) {
      totalCompound += parseFloat(trailingDigitMatch[0]);
    } else if (cleanRemainder) {
      const sortedKeys = Object.keys(MULTI_LANG_NUM_WORDS).sort((a, b) => b.length - a.length);
      for (const k of sortedKeys) {
        const rx = new RegExp(`(?:^|[^\\p{L}\\p{N}])${escapeRegExp(k)}(?=[^\\p{L}\\p{N}]|$)`, 'iu');
        if (rx.test(cleanRemainder)) {
          totalCompound += MULTI_LANG_NUM_WORDS[k];
          break;
        }
      }
    }
    return Math.round(totalCompound);
  }

  // 7. Arithmetic expressions (e.g. "500 + 200" or "500 aur 200")
  const plusRegex = /(\d+(?:\.\d+)?)\s*(?:\+|\bplus\b|\baur\b|اور|جمع|और|\&)\s*(\d+(?:\.\d+)?)/gi;
  let pMatch: RegExpExecArray | null;
  let sumArithmetic = 0;
  let foundArithmetic = false;
  while ((pMatch = plusRegex.exec(s)) !== null) {
    foundArithmetic = true;
    sumArithmetic += parseFloat(pMatch[1]) + parseFloat(pMatch[2]);
  }
  if (foundArithmetic && sumArithmetic > 0) return Math.round(sumArithmetic);

  // 8. Plain digits (e.g. "155000", "10220", "1252", "55", "52", "53")
  const plainDigitMatch = s.match(/\b\d+(?:\.\d+)?\b/);
  if (plainDigitMatch) {
    return Math.round(parseFloat(plainDigitMatch[0]));
  }

  // 9. Plain word from dictionary (exact match or word boundary)
  const sortedKeys = Object.keys(MULTI_LANG_NUM_WORDS).sort((a, b) => b.length - a.length);
  for (const k of sortedKeys) {
    const rx = new RegExp(`(?:^|[^\\p{L}\\p{N}])${escapeRegExp(k)}(?=[^\\p{L}\\p{N}]|$)`, 'iu');
    if (rx.test(s)) {
      return MULTI_LANG_NUM_WORDS[k];
    }
  }

  return 0;
}

/**
 * Extracts person name from verbal text in Khata context
 */
export function extractPersonName(text: string, customers: Customer[] = []): string {
  const clean = text.trim();
  const normalized = normalizeUrdu(clean).toLowerCase();

  // 1. Check existing customer accounts
  for (const c of customers) {
    const cNorm = normalizeUrdu(c.name).toLowerCase();
    const cUrduNorm = normalizeUrdu(c.nameUrdu).toLowerCase();
    if (cNorm && normalized.includes(cNorm)) return c.name;
    if (cUrduNorm && normalized.includes(cUrduNorm)) return c.nameUrdu || c.name;
  }

  // 2. Check URDU_NAME_MAPPINGS
  for (const [urdu, eng] of Object.entries(URDU_NAME_MAPPINGS)) {
    if (normalized.includes(urdu) || normalized.includes(eng.toLowerCase())) {
      return eng;
    }
  }

  // 3. Extraction with relationship keywords (e.g. "علی سے", "احمد کو", "عثمان کا", "بلال نے")
  const namePattern = /([\u0600-\u06FFa-zA-Z]+)\s*(?:سے|کو|کا|کے|کی|نے|se|ko|ka)/i;
  const match = clean.match(namePattern);
  if (match && match[1]) {
    const candidate = match[1].trim();
    const stopWords = ['پیسے', 'روپے', 'ادھار', 'وصول', 'بل', 'سیلری', 'خرچ', 'بجٹ', 'کھاتہ', 'آج', 'کل', 'انکم', 'کٹوتی'];
    if (!stopWords.includes(candidate)) {
      return candidate;
    }
  }

  return customers.length > 0 ? (customers[0].nameUrdu || customers[0].name) : 'Customer';
}

/**
 * Intelligent Voice Parser for Financial Ledger & Task Entries
 * Implements Section 1, 2, 3, 4 strictly
 */
export function parseIntelligentVoiceEntry(
  rawText: string,
  contextHint: VoiceParserTab = 'Khata',
  customers: Customer[] = [],
  forcedKhataType?: 'Credit' | 'Debit',
  targetCustomer?: Customer | null
): IntelligentVoiceParserResult {
  const cleanText = rawText.trim();
  const normalized = normalizeUrdu(cleanText).toLowerCase();

  // Khata / Supply Ledger
  const tab: VoiceParserTab = 'Khata';

  // Normalize amount using Section 4 Number Normalization
  const parsed_amount = normalizeNumberFromSpoken(cleanText);

  // -------------------------------------------------------------
  // SECTION 1: KHATA TAB LOGIC (Customer Debt / Balance)
  // When in "Khata" context:
  // 1. CREDIT / RECEIVED (وصول ہوا / پیسے ملے / کٹوتی):
  //    Keywords: "وصول ہوا", "پیسے ملے", "واپس ملے", "کٹوتی", "Credit", "Received"
  //    Math Action: SUBTRACT (-) from Customer Debt.
  //    Formula: Remaining Debt = Current Balance - Parsed Amount
  // 2. DEBIT / GIVEN (دیے / ادھار / कर्ज):
  //    Keywords: "دیے", "ادھار دیا", "قرضہ ہوا", "Debit", "Gave"
  //    Math Action: ADD (+) to Customer Debt.
  //    Formula: New Debt = Current Balance + Parsed Amount
  // -------------------------------------------------------------
  let transaction_type: 'Credit' | 'Debit' = 'Debit';
  let math_action: 'SUBTRACT' | 'ADD' = 'ADD';

    if (forcedKhataType) {
      transaction_type = forcedKhataType;
      math_action = forcedKhataType === 'Credit' ? 'SUBTRACT' : 'ADD';
    } else {
      const creditKeywords = [
        'وصولی', 'ملا', 'ملے', 'وصول ہوا', 'پیسے ملے', 'واپس ملے', 'کٹوتی', 'credit', 'received',
        'وصول', 'پیسے آئے', 'مل گئے', 'جمع', 'ملی', 'پائے'
      ];
      const isCredit = creditKeywords.some((kw) => normalized.includes(normalizeUrdu(kw)));

      const debitKeywords = [
        'قرض دیا', 'دیا', 'دیے', 'ادھار دیا', 'قرضہ ہوا', 'debit', 'gave',
        'دئے', 'دیئے', 'ادھار', 'قرض', 'رقم دی', 'دے دیے', 'دینا'
      ];
      const isDebit = debitKeywords.some((kw) => normalized.includes(normalizeUrdu(kw)));

      if (isCredit && !isDebit) {
        transaction_type = 'Credit';
        math_action = 'SUBTRACT';
      } else if (isDebit) {
        transaction_type = 'Debit';
        math_action = 'ADD';
      } else {
        if (normalized.includes('آئے') || normalized.includes('لیے') || normalized.includes('got') || normalized.includes('ملا')) {
          transaction_type = 'Credit';
          math_action = 'SUBTRACT';
        } else {
          transaction_type = 'Debit';
          math_action = 'ADD';
        }
      }
    }

    const person_name = targetCustomer
      ? targetCustomer.nameUrdu || targetCustomer.name
      : extractPersonName(cleanText, customers);
    const customer_id = targetCustomer ? targetCustomer.id : undefined;

    return {
      tab: 'Khata',
      original_spoken_text: cleanText,
      person_name,
      customer_id,
      parsed_amount,
      transaction_type,
      math_action,
    };
}

/**
 * Format pure JSON output strictly matching the required schema:
 */
export function formatIntelligentParserJson(result: IntelligentVoiceParserResult): string {
  const obj: Record<string, any> = {
    tab: 'Khata',
    original_spoken_text: result.original_spoken_text,
    person_name: result.person_name,
  };
  if (result.customer_id) {
    obj.customer_id = result.customer_id;
  }
  obj.parsed_amount = result.parsed_amount;
  obj.transaction_type = result.transaction_type;
  obj.math_action = result.math_action;

  return JSON.stringify(obj, null, 2);
}

/**
 * Compatibility wrapper for application components
 */
export function parseFinancialVoiceCommand(
  rawText: string,
  selectedTabContext: VoiceParserTab | FinancialTab = 'Khata',
  customers: Customer[] = [],
  forcedKhataType?: 'Credit' | 'Debit',
  targetCustomer?: Customer | null
): FinancialVoiceOutput {
  const result = parseIntelligentVoiceEntry(rawText, 'Khata', customers, forcedKhataType, targetCustomer);

  const effectiveCustomerId = targetCustomer ? targetCustomer.id : result.customer_id;
  const effectiveName = targetCustomer ? targetCustomer.name : result.person_name;
  const effectiveUrduName = targetCustomer ? (targetCustomer.nameUrdu || targetCustomer.name) : result.person_name;

  return {
    selected_tab: 'Khata/Supply',
    entry_type: result.transaction_type,
    amount: result.parsed_amount,
    description: `${effectiveUrduName} - ${result.transaction_type === 'Credit' ? 'وصول ہوا (Credit / SUBTRACT)' : 'دیے (Debit / ADD)'}`,
    math_action: result.math_action === 'SUBTRACT' ? 'MINUS (-)' : 'PLUS (+)',
    customerId: effectiveCustomerId,
    customerName: effectiveName,
    customerUrdu: effectiveUrduName,
    tab: 'Khata',
    original_spoken_text: result.original_spoken_text,
    person_name: effectiveUrduName,
    customer_id: effectiveCustomerId,
    parsed_amount: result.parsed_amount,
    transaction_type: result.transaction_type,
  };
}
