import { SubscriptionInfo } from '../types';

export const ADMIN_PIN = 'ADMIN123';
export const SUPPORT_WHATSAPP = '923001234567';
export const SUPPORT_EMAIL = 'kpkfaisal.khan13@gmail.com';

export const DEFAULT_SUBSCRIPTION: SubscriptionInfo = {
  installedAt: new Date().toISOString(), // Day 1
  voiceExpiresAt: null,
  pdfAnalyticsExpiresAt: null,
  adminExtendedDays: 0,
};

export interface TrialStatus {
  isTrialActive: boolean;
  daysUsed: number;
  daysRemaining: number;
  currentDay: number;
}

export function getTrialStatus(sub?: SubscriptionInfo): TrialStatus {
  if (!sub || !sub.installedAt) {
    return { isTrialActive: true, daysUsed: 1, daysRemaining: 29, currentDay: 1 };
  }

  const installTime = new Date(sub.installedAt).getTime();
  const now = Date.now();
  const diffDays = Math.floor((now - installTime) / (1000 * 60 * 60 * 24));
  const currentDay = Math.max(1, diffDays + 1);
  const isTrialActive = currentDay <= 30;
  const daysRemaining = Math.max(0, 30 - currentDay);

  return {
    isTrialActive,
    daysUsed: Math.min(30, currentDay),
    daysRemaining,
    currentDay,
  };
}

export function isVoiceFeatureUnlocked(_sub?: SubscriptionInfo): boolean {
  // Free Tier: Basic manual & voice ledger + Voice Calculator are always free!
  return true;
}

export function isPdfAnalyticsUnlocked(sub?: SubscriptionInfo): boolean {
  if (!sub) return true;
  
  // Instant 24-hour temporary access upon payment screenshot submission
  if (sub.tempAccessUntil && new Date(sub.tempAccessUntil).getTime() > Date.now()) {
    return true;
  }

  const trial = getTrialStatus(sub);
  if (trial.isTrialActive) return true; // Day 1 to 30: 1-Month Free Trial

  // Day 31 onwards: check if active subscription
  if (sub.pdfAnalyticsExpiresAt) {
    return new Date(sub.pdfAnalyticsExpiresAt).getTime() > Date.now();
  }
  return false;
}

export function buildWhatsAppVerificationUrl(params: {
  shopName: string;
  shopOwner: string;
  planName: string;
  price: string;
  txzId: string;
  paymentMethod: string;
}): string {
  const text = `السلام علیکم! میں نے کھاتہ ایپ کی فیس ادا کر دی ہے۔
📌 دکان کا نام: ${params.shopName}
👤 مالک کا نام: ${params.shopOwner}
💎 منتخب پلان: ${params.planName} (${params.price})
💳 ادائیگی کا ذریعہ: ${params.paymentMethod}
🔢 ٹرانزیکشن ID (TXZ ID): ${params.txzId}
تاریخ: ${new Date().toLocaleDateString('ur-PK')}

براہ کرم رسید چیک کر کے میرا پلان ۳۰ دن کے لیے ایکٹیو فرما دیں۔ شکریہ!`;

  return `https://wa.me/${SUPPORT_WHATSAPP}?text=${encodeURIComponent(text)}`;
}

export function buildGmailVerificationUrl(params: {
  shopName: string;
  shopOwner: string;
  planName: string;
  price: string;
  txzId: string;
  paymentMethod: string;
}): string {
  const subject = encodeURIComponent('Payment Proof - Udhaar App');
  const body = encodeURIComponent(`Payment Proof - Voice Udhaar & Ledger App

Shop Name: ${params.shopName}
Owner Name: ${params.shopOwner}
Selected Plan: ${params.planName} (${params.price})
Payment Method: ${params.paymentMethod}
Transaction ID (TXZ ID): ${params.txzId}
Date: ${new Date().toLocaleString()}

Please verify this transaction and extend my account subscription.
Attached or reference TXZ: ${params.txzId}

Thank you!`);

  return `mailto:${SUPPORT_EMAIL}?subject=${subject}&body=${body}`;
}
