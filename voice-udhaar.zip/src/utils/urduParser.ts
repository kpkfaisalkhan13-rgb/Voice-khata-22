import {
  Customer,
  TransactionType,
  VoiceParseResult,
  VoiceIntent,
  VoiceIntentClassification,
  ExtractedTransaction,
  MultiTransactionParseResponse,
  MultiVoiceParseResult,
  VoiceEngineMode,
  VoiceEngineLedgerData,
  VoiceEngineCalculatorData,
  VoiceEngineResponse,
} from '../types';
import { parseEnglishNumberText, englishNumberDict } from './englishNumberParser';
import { dbService } from '../services/db';

export { parseEnglishNumberText, englishNumberDict };

// Map Urdu and Arabic digits to Latin digits
export const URDU_DIGITS_MAP: Record<string, string> = {
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
};

// 1. اعداد کی بنیادی ڈکشنری (Words to Numbers Map)
export const urduNumberDict: Record<string, number> = {
  // اکائیاں اور دہائیاں (1 to 20)
  'ایک': 1, 'ایک سو': 100, 'دو': 2, 'تین': 3, 'چار': 4, 'پانچ': 5,
  'چھ': 6, 'چہ': 6, 'چھے': 6, 'سات': 7, 'آٹھ': 8, 'اٹھ': 8, 'نو': 9, 'دس': 10,
  'گیارہ': 11, 'بارہ': 12, 'تیرہ': 13, 'چودہ': 14, 'پندرہ': 15,
  'سولہ': 16, 'سترہ': 17, 'اٹھارہ': 18, 'اٹہارہ': 18, 'انیس': 19, 'بیس': 20,

  // اکیس تا سو (21 to 100)
  'اکیس': 21, 'بائیس': 22, 'بائس': 22, 'تیئیس': 23, 'تئیس': 23, 'چوبیس': 24, 'پچیس': 25, 'چھبیس': 26, 'ستائیس': 27, 'ستائس': 27,
  'اٹھائیس': 28, 'اٹائیس': 28, 'انتیس': 29, 'تیس': 30,
  'اکتیس': 31, 'بتیس': 32, 'تینتیس': 33, 'چونتیس': 34, 'پینتیس': 35, 'چھتیس': 36, 'سینتیس': 37, 'اڑتیس': 38, 'انتالیس': 39, 'چالیس': 40,
  'اکتالیس': 41, 'بیالیس': 42, 'تینتالیس': 43, 'چوالیس': 44, 'پینتالیس': 45, 'چھیالیس': 46, 'سینتالیس': 47, 'اڑتالیس': 48, 'انچاس': 49, 'پچاس': 50,
  'ایکاون': 51, 'اکیاون': 51, 'باون': 52, 'ترپن': 53, 'چوون': 54, 'چون': 54, 'پچپن': 55, 'چھپن': 56, 'ستاون': 57, 'اٹھاون': 58, 'انسٹھ': 59, 'ساٹھ': 60,
  'اکسٹھ': 61, 'باسٹھ': 62, 'تریسٹھ': 63, 'چونسٹھ': 64, 'پینسٹھ': 65, 'چھیاسٹھ': 66, 'سڑسٹھ': 67, 'اڑسٹھ': 68, 'انہتر': 69, 'ستر': 70, 'ستار': 70,
  'اکہتر': 71, 'بہتر': 72, 'تہتر': 73, 'چوہتر': 74, 'پچہتر': 75, 'چھہتر': 76, 'ستتر': 77, 'اٹھہتر': 78, 'اناسی': 79, 'اسی': 80,
  'اکیاسی': 81, 'بیاسی': 82, 'تراسی': 83, 'چوراسی': 84, 'پچاسی': 85, 'چھیاسی': 86, 'ستاسی': 87, 'اٹھاسی': 88, 'نواسی': 89, 'نوے': 90,
  'اکانوے': 91, 'بانوے': 92, 'ترانوے': 93, 'چورانوے': 94, 'پچانوے': 95, 'چھیانوے': 96, 'ستانوے': 97, 'اٹھانوے': 98, 'ننانوے': 99,

  // سو، ہزار، لاکھ (Multipliers)
  'سو': 100, 'سیکڑا': 100,
  'ہزار': 1000,
  'لاکھ': 100000,
  'کرور': 10000000,
  'کروڑ': 10000000,

  // رومن اردو الفاظ (Roman Urdu Support)
  'ek': 1, 'aik': 1, 'do': 2, 'teen': 3, 'chaar': 4, 'char': 4, 'paanch': 5, 'panch': 5,
  'che': 6, 'chey': 6, 'saat': 7, 'aath': 8, 'ath': 8, 'nau': 9, 'das': 10,
  'gyarah': 11, 'barah': 12, 'terah': 13, 'chaudah': 14, 'chauda': 14, 'pandrah': 15,
  'solah': 16, 'satrah': 17, 'atharah': 18, 'unnees': 19,
  'beas': 20, 'bees': 20, 'ikkis': 21, 'baees': 22, 'bayees': 22, 'teyees': 23, 'chaubees': 24,
  'pachees': 25, 'pachis': 25, 'chhabees': 26, 'sataees': 27, 'athaees': 28, 'untees': 29,
  'tees': 30, 'iktees': 31, 'batees': 32, 'tentees': 33, 'chauntees': 34, 'paintees': 35,
  'chhatees': 36, 'saintees': 37, 'artees': 38, 'untalees': 39,
  'chalis': 40, 'chalees': 40, 'iktalis': 41, 'bayalis': 42, 'paintalis': 45, 'unchaas': 49,
  'pachas': 50,
  'ekawan': 51, 'ikawan': 51, 'bawan': 52, 'baawan': 52, 'tirpan': 53, 'tarpan': 53,
  'chawan': 54, 'chauwan': 54, 'pachpan': 55, 'chappan': 56, 'satawan': 57, 'athawan': 58, 'unsath': 59,
  'saath': 60, 'sath': 60,
  'sattar': 70, 'satar': 70,
  'assi': 80,
  'nawwe': 90, 'nave': 90,
  'sau': 100, 'so': 100, 'saikra': 100,
  'hazaar': 1000, 'hazar': 1000,
  'lakh': 100000, 'lac': 100000,
  'crore': 10000000, 'karor': 10000000,
};

// 2. بولے گئے جملے سے عدد نکالنے کا الگورتھم
export function parseUrduNumberText(text: string): number {
  if (!text) return 0;

  // Normalize digits (convert Urdu/Arabic digits to Latin)
  let normalized = text;
  for (const [urduChar, latinChar] of Object.entries(URDU_DIGITS_MAP)) {
    normalized = normalized.split(urduChar).join(latinChar);
  }

  // Check comma-formatted sequences like 10,220 or 12,250
  const commaMatches = normalized.match(/\b\d{1,3}(?:,\d{2,3})+(?:\.\d+)?\b/);
  if (commaMatches) {
    const directVal = parseFloat(commaMatches[0].replace(/,/g, ''));
    if (!isNaN(directVal) && directVal > 0) return Math.round(directVal);
  }

  // Clean punctuation and normalize whitespace
  const clean = normalized
    .replace(/[،۔!?,:;'"()[\]{}]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const words = clean.split(' ');
  let total = 0;
  let currentGroup = 0;
  let hasMatched = false;

  for (const word of words) {
    if (!word) continue;
    const lower = word.toLowerCase();

    // Direct numeric digits (e.g. 10220 or 12250)
    if (/^\d+(?:\.\d+)?$/.test(word)) {
      currentGroup += parseFloat(word);
      hasMatched = true;
      continue;
    }

    if (urduNumberDict[word] !== undefined || urduNumberDict[lower] !== undefined) {
      hasMatched = true;
      const value = urduNumberDict[word] ?? urduNumberDict[lower];

      // اگر لفظ 'ہزار' یا 'لاکھ' یا 'سو' ہو تو ضرب (Multiply) کریں
      if (value === 100) {
        currentGroup = (currentGroup === 0 ? 1 : currentGroup) * 100;
      } else if (value >= 1000) {
        currentGroup = (currentGroup === 0 ? 1 : currentGroup) * value;
        total += currentGroup;
        currentGroup = 0;
      } else {
        currentGroup += value;
      }
    }
  }

  total += currentGroup;
  return hasMatched ? Math.round(total) : 0;
}

// Common Urdu name mappings (Urdu <-> English transliteration)
export const URDU_NAME_MAPPINGS: Record<string, string> = {
  'علی': 'Ali',
  'احمد': 'Ahmed',
  'حمزہ': 'Hamza',
  'عثمان': 'Usman',
  'بلال': 'Bilal',
  'طارق': 'Tariq',
  'کامران': 'Kamran',
  'عمر': 'Umar',
  'خان': 'Khan',
  'زاہد': 'Zahid',
  'وقار': 'Waqar',
  'اصغر': 'Asghar',
  'سلمان': 'Salman',
  'رضوان': 'Rizwan',
  'فہد': 'Fahad',
  'حسن': 'Hassan',
  'حسین': 'Hussain',
  'قاسم': 'Qasim',
  'عبداللہ': 'Abdullah',
  'راشد': 'Rashid',
  'سلیم': 'Saleem',
  'عرفان': 'Irfan',
  'فاروق': 'Farooq',
  'ساجد': 'Sajid',
  'ارسلان': 'Arslan',
  'شہزاد': 'Shehzad',
  'نوید': 'Naveed',
  'کاشف': 'Kashif',
  'افتخار': 'Iftikhar',
  'جاوید': 'Javed',
  'راہول': 'Rahul',
  'امجد': 'Amjad',
  'بابر': 'Babar',
  'ندیم': 'Nadeem',
};

// Reverse mapping for English names to Urdu
export const ENGLISH_TO_URDU_MAP: Record<string, string> = Object.entries(
  URDU_NAME_MAPPINGS
).reduce((acc, [ur, en]) => {
  acc[en.toLowerCase()] = ur;
  return acc;
}, {} as Record<string, string>);

// Normalize Urdu text (remove diacritics, normalize alef, yeh, heh)
export function normalizeUrdu(text: string): string {
  if (!text) return '';
  return text
    .replace(/[\u064B-\u065F\u0670]/g, '') // remove arabic tashkeel / harakat
    .replace(/[آأإ]/g, 'ا')
    .replace(/[يى]/g, 'ی')
    .replace(/[ك]/g, 'ک')
    .replace(/[ة]/g, 'ہ')
    .replace(/[ھ]/g, 'ہ')
    .replace(/[،,]/g, ' ')
    .trim();
}

/**
 * Parses single or compound arithmetic mathematical expressions from Urdu/English text:
 * E.g., "500 plus 200" -> 700
 * "500 aur 200" -> 700
 * "500 جمع 200" -> 700
 * "Received 1200 from Rahul" -> 1200
 */
export function parseUrduNumber(text: string): number | null {
  if (!text) return null;

  // 0. Auto-Lookup user_voice_corrections before default parser / AI
  try {
    const correction = dbService.findVoiceCorrection(text);
    if (correction && correction.corrected_number > 0) {
      return correction.corrected_number;
    }
  } catch {
    // Ignore fallback
  }

  // 1. Direct Urdu/Roman-Urdu exact spoken number parsing (local offline parser)
  const offlineParsed = parseUrduNumberText(text);
  if (offlineParsed > 0) {
    return offlineParsed;
  }

  // 2. Direct English spoken number parsing (local offline parser)
  const englishParsed = parseEnglishNumberText(text);
  if (englishParsed > 0) {
    return englishParsed;
  }

  // Replace Urdu/Arabic digits first
  let normalized = text;
  for (const [urduChar, latinChar] of Object.entries(URDU_DIGITS_MAP)) {
    normalized = normalized.split(urduChar).join(latinChar);
  }
  normalized = normalized.replace(/,/g, '');

  // Check for arithmetic addition patterns:
  // e.g. "500 plus 200", "500 + 200", "500 aur 200", "500 اور 200", "500 جمع 200"
  const mathRegex = /(\d+(?:\.\d+)?)\s*(?:plus|\+|\band\b|\baur\b|اور|جمع|\&)\s*(\d+(?:\.\d+)?)/gi;
  let mathMatch = mathRegex.exec(normalized);
  if (mathMatch) {
    let sum = 0;
    // Iterate over all additions if chained (e.g. 500 + 200 + 100)
    let remainder = normalized;
    let match: RegExpExecArray | null;
    const allMatchesRegex = /(\d+(?:\.\d+)?)\s*(?:plus|\+|\band\b|\baur\b|اور|جمع|\&)\s*(\d+(?:\.\d+)?)/gi;
    let foundAny = false;
    while ((match = allMatchesRegex.exec(remainder)) !== null) {
      foundAny = true;
      const n1 = parseFloat(match[1]);
      const n2 = parseFloat(match[2]);
      sum += (n1 + n2);
    }
    if (foundAny && sum > 0) return sum;
  }

  // Check digit sequences like 1200, 10000, 40000
  const allDigits = normalized.match(/\b\d+(?:\.\d+)?\b/g);
  if (allDigits && allDigits.length > 0) {
    // If multiple numbers separated by words like "plus" or "aur" were caught
    const isSumContext = /plus|\+|\baur\b|اور|جمع/i.test(normalized);
    if (isSumContext && allDigits.length > 1) {
      return allDigits.reduce((acc, curr) => acc + (parseFloat(curr) || 0), 0);
    }
    return parseFloat(allDigits[0]);
  }

  // Spoken Urdu numbers mapping
  const wordMultipliers: Record<string, number> = {
    'سو': 100,
    'ہزار': 1000,
    'لاکھ': 100000,
    'کروڑ': 10000000,
  };

  const urduUnits: Record<string, number> = {
    'ایک': 1, 'دو': 2, 'تین': 3, 'چار': 4, 'پانچ': 5,
    'چھ': 6, 'سات': 7, 'آٹھ': 8, 'نو': 9, 'دس': 10,
    'گیارہ': 11, 'بارہ': 12, 'تیرہ': 13, 'چودہ': 14, 'پندرہ': 15,
    'سولہ': 16, 'سترہ': 17, 'اٹھارہ': 18, 'انیس': 19, 'بیس': 20,
    'پچیس': 25, 'تیس': 30, 'پینتیس': 35, 'چالیس': 40,
    'پینتالیس': 45, 'پچاس': 50, 'ساٹھ': 60, 'ستر': 70,
    'اسی': 80, 'نوے': 90,
  };

  // Check compound like "دس ہزار"
  for (const [unitWord, unitVal] of Object.entries(urduUnits)) {
    for (const [multWord, multVal] of Object.entries(wordMultipliers)) {
      if (normalized.includes(`${unitWord} ${multWord}`) || normalized.includes(`${unitWord}${multWord}`)) {
        return unitVal * multVal;
      }
    }
  }

  if (normalized.includes('پانچ سو')) return 500;
  if (normalized.includes('دو سو')) return 200;
  if (normalized.includes('تین سو')) return 300;
  if (normalized.includes('چار سو')) return 400;
  if (normalized.includes('سو')) return 100;
  if (normalized.includes('ہزار')) return 1000;
  if (normalized.includes('لاکھ')) return 100000;

  return null;
}

/**
 * Intent Recognition:
 * - "Give / Diye / Bheje": DEBIT (You gave money)
 * - "Got / Milay / Liya / Aaye": CREDIT (You received money)
 */
export function parseTransactionType(text: string): { type: TransactionType; matchedKeyword: string } {
  const lower = text.toLowerCase();
  const normalized = normalizeUrdu(lower);

  // CREDIT indicators (customer paid merchant / merchant received money):
  // "Got", "Milay", "Liya", "Aaye", "Received", "Wapas kiye", "Wapas", "Wasool", "Jama"
  const creditKeywords = [
    'received',
    'got',
    'milay',
    'miley',
    'mila',
    'liya',
    'aaye',
    'aye',
    'wapas kiye',
    'wapas kia',
    'wapas',
    'وصول ہوئے',
    'وصول ہوا',
    'وصول',
    'نقد ملے',
    'نقد ملا',
    'جمع کرائے',
    'جمع کرو',
    'جمع کیے',
    'واپس کیے',
    'واپس کیا',
    'واپس دیا',
    'ادا کیے',
    'ملے',
    'موصول',
    'credit',
    'jama',
  ];

  for (const kw of creditKeywords) {
    if (lower.includes(kw) || normalized.includes(normalizeUrdu(kw))) {
      return { type: 'CREDIT', matchedKeyword: kw };
    }
  }

  // DEBIT indicators (merchant gave money / customer borrowed):
  // "Give", "Diye", "Bheje", "Likh do", "Qarz", "Udhaar"
  const debitKeywords = [
    'give',
    'gave',
    'diye',
    'diya',
    'die',
    'bheje',
    'bheja',
    'udhaar',
    'qarz',
    'debit',
    'قرض لیا',
    'قرض دیا',
    'قرض',
    'ادھار دیا',
    'ادھار لیا',
    'ادھار',
    'لکھ دو',
    'لکھو',
    'کھاتے میں',
    'دیے',
    'دے دیے',
    'ڈالو',
    'قرضہ',
  ];

  for (const kw of debitKeywords) {
    if (lower.includes(kw) || normalized.includes(normalizeUrdu(kw))) {
      return { type: 'DEBIT', matchedKeyword: kw };
    }
  }

  return { type: 'DEBIT', matchedKeyword: 'default_debit' };
}

/**
 * Extract candidate customer name from Urdu, Roman Urdu, or English transcript:
 * Handles:
 * - "Received 1200 from Rahul"
 * - "Ali ko 500 diye"
 * - "Usman ne 300 wapas kiye"
 * - "Ali ke khate me 500 likho"
 * - "علی کے کھاتے میں 10,000 لکھ دو"
 */
export function extractCustomerNameCandidate(text: string): { urduName: string; englishName: string } {
  const clean = text.replace(/[،۔!?,]/g, ' ').trim();
  const lower = clean.toLowerCase();

  // Pattern A: English "from [Name]" e.g. "Received 1200 from Rahul"
  const fromMatch = clean.match(/(?:from|to|for)\s+([A-Za-z]+)/i);
  if (fromMatch && fromMatch[1]) {
    const raw = fromMatch[1].trim();
    if (!['me', 'the', 'my', 'him', 'her'].includes(raw.toLowerCase())) {
      return mapCandidateNameToPair(raw);
    }
  }

  // Pattern B: Roman Urdu "[Name] ko ..." e.g. "Ali ko 500 diye"
  const romanKoMatch = clean.match(/(?:^|\s)([A-Za-z]+)\s+ko\b/i);
  if (romanKoMatch && romanKoMatch[1]) {
    return mapCandidateNameToPair(romanKoMatch[1].trim());
  }

  // Pattern C: Roman Urdu "[Name] ne ..." e.g. "Usman ne 300 wapas kiye"
  const romanNeMatch = clean.match(/(?:^|\s)([A-Za-z]+)\s+ne\b/i);
  if (romanNeMatch && romanNeMatch[1]) {
    return mapCandidateNameToPair(romanNeMatch[1].trim());
  }

  // Pattern D: Roman Urdu "[Name] se ..." e.g. "Rahul se 1200 milay"
  const romanSeMatch = clean.match(/(?:^|\s)([A-Za-z]+)\s+se\b/i);
  if (romanSeMatch && romanSeMatch[1]) {
    return mapCandidateNameToPair(romanSeMatch[1].trim());
  }

  // Pattern E: Urdu "... کے کھاتے میں"
  const khataMatch = clean.match(/(?:^|\s)([\u0600-\u06FF\w\s]{2,20}?)\s+کے\s+کھاتے/);
  if (khataMatch && khataMatch[1]) {
    const raw = khataMatch[1].trim();
    const words = raw.split(/\s+/).filter(Boolean);
    const candidate = words.slice(-2).join(' ');
    return mapCandidateNameToPair(candidate);
  }

  // Pattern F: Urdu "... کو [رقم] دیے" or "... کو"
  const koMatch = clean.match(/(?:^|\s)([\u0600-\u06FF\w\s]{2,15}?)\s+کو/);
  if (koMatch && koMatch[1]) {
    const raw = koMatch[1].trim();
    const words = raw.split(/\s+/).filter(Boolean);
    const candidate = words.slice(-2).join(' ');
    return mapCandidateNameToPair(candidate);
  }

  // Pattern G: Urdu "... نے"
  const neMatch = clean.match(/(?:^|\s)([\u0600-\u06FF\w\s]{2,15}?)\s+نے/);
  if (neMatch && neMatch[1]) {
    const raw = neMatch[1].trim();
    const words = raw.split(/\s+/).filter(Boolean);
    const candidate = words.slice(-2).join(' ');
    return mapCandidateNameToPair(candidate);
  }

  // Pattern H: Urdu "... سے وصول" or "... سے"
  const seMatch = clean.match(/(?:^|\s)([\u0600-\u06FF\w\s]{2,15}?)\s+سے/);
  if (seMatch && seMatch[1]) {
    const raw = seMatch[1].trim();
    const words = raw.split(/\s+/).filter(Boolean);
    const candidate = words.slice(-2).join(' ');
    return mapCandidateNameToPair(candidate);
  }

  // Pattern I: Check known names directly in text
  for (const [urName, enName] of Object.entries(URDU_NAME_MAPPINGS)) {
    if (clean.includes(urName) || lower.includes(enName.toLowerCase())) {
      return { urduName: urName, englishName: enName };
    }
  }

  // Fallback: Check first word
  const firstWord = clean.split(/\s+/)[0] || 'کسٹمر';
  return mapCandidateNameToPair(firstWord);
}

function mapCandidateNameToPair(candidate: string): { urduName: string; englishName: string } {
  const norm = normalizeUrdu(candidate);

  // Check if matches known Urdu name
  for (const [urName, enName] of Object.entries(URDU_NAME_MAPPINGS)) {
    if (norm === normalizeUrdu(urName) || norm.includes(normalizeUrdu(urName))) {
      return { urduName: urName, englishName: enName };
    }
  }

  // Check if candidate is in English / Roman
  const lower = candidate.toLowerCase();
  for (const [enName, urName] of Object.entries(ENGLISH_TO_URDU_MAP)) {
    if (lower === enName || lower.includes(enName)) {
      return { urduName: urName, englishName: enName.charAt(0).toUpperCase() + enName.slice(1) };
    }
  }

  // Capitalize candidate for English display
  const formattedEn = candidate.charAt(0).toUpperCase() + candidate.slice(1);
  const isUrdu = /[\u0600-\u06FF]/.test(candidate);
  return {
    urduName: isUrdu ? candidate : (ENGLISH_TO_URDU_MAP[candidate.toLowerCase()] || candidate),
    englishName: isUrdu ? (URDU_NAME_MAPPINGS[candidate] || candidate) : formattedEn
  };
}

/**
 * Match candidate against customer database
 */
export function matchCustomerInDb(candidateUrdu: string, candidateEn: string, customers: Customer[]): Customer | null {
  const normCandidateUrdu = normalizeUrdu(candidateUrdu).toLowerCase();
  const normCandidateEn = candidateEn.toLowerCase();

  // 1. Exact match on Urdu name or English name
  for (const c of customers) {
    const cNormUrdu = normalizeUrdu(c.nameUrdu).toLowerCase();
    const cNormEn = c.name.toLowerCase();

    if (
      (normCandidateUrdu && cNormUrdu === normCandidateUrdu) ||
      (normCandidateEn && cNormEn === normCandidateEn) ||
      (normCandidateUrdu && cNormUrdu.includes(normCandidateUrdu)) ||
      (normCandidateEn && cNormEn.includes(normCandidateEn))
    ) {
      return c;
    }
  }

  // 2. Tokenized matching (e.g. "Ali" in "Ali Khan", "علی" in "علی احمد")
  for (const c of customers) {
    const cUrduTokens = normalizeUrdu(c.nameUrdu).toLowerCase().split(/\s+/);
    const cEnTokens = c.name.toLowerCase().split(/\s+/);

    if (
      cUrduTokens.some(t => t && normCandidateUrdu && (t === normCandidateUrdu || normCandidateUrdu.includes(t))) ||
      cEnTokens.some(t => t && normCandidateEn && (t === normCandidateEn || normCandidateEn.includes(t)))
    ) {
      return c;
    }
  }

  return null;
}

/**
 * Complete Voice Parser:
 * Supports optional pre-extracted Groq AI JSON output, or performs full local parsing
 */
export function parseUrduVoiceCommand(
  transcript: string,
  existingCustomers: Customer[],
  groqExtracted?: { account_name?: string; amount?: number; type?: 'CREDIT' | 'DEBIT' } | null
): VoiceParseResult {
  const cleanTranscript = transcript.trim();

  let englishName = '';
  let urduName = '';
  let amount = 0;
  let type: TransactionType = 'DEBIT';

  if (groqExtracted && groqExtracted.account_name && (groqExtracted.amount || 0) > 0) {
    const mapped = mapCandidateNameToPair(groqExtracted.account_name);
    englishName = mapped.englishName;
    urduName = mapped.urduName;
    amount = groqExtracted.amount || 0;
    type = groqExtracted.type || 'DEBIT';
  } else {
    const candidate = extractCustomerNameCandidate(cleanTranscript);
    englishName = candidate.englishName;
    urduName = candidate.urduName;
    amount = parseUrduNumber(cleanTranscript) || 0;
    type = parseTransactionType(cleanTranscript).type;
  }

  const matchedCustomer = matchCustomerInDb(urduName, englishName, existingCustomers);

  return {
    customerName: matchedCustomer ? matchedCustomer.name : englishName,
    customerNameUrdu: matchedCustomer ? matchedCustomer.nameUrdu : urduName,
    amount,
    type,
    rawText: cleanTranscript,
    matchedCustomer,
    exists: !!matchedCustomer,
    notes: `Voice: "${cleanTranscript}"`
  };
}

/**
 * Local Rule-based Intent Classifier for "Voice Udhaar" search queries
 * Task:
 * Determine if the user wants to ADD a transaction or SEARCH/QUERY an existing account.
 */
export function classifyVoiceIntentLocal(transcript: string): VoiceIntentClassification {
  const clean = transcript.trim();

  // Search patterns in English / Roman Urdu / Urdu
  // 1. "Ali ka khata dikhao", "Rahul ka hisab", "Usman ka balance dikhao", "Tariq ka ledger"
  const romanKhataMatch = clean.match(
    /(?:^|\s)([a-zA-Z\u0600-\u06FF\s]{2,25}?)\s+ka\s+(?:khata|hisab|balance|ledger|record|kitna\s+banta|kitne\s+paise)/i
  );
  if (romanKhataMatch && romanKhataMatch[1]) {
    const rawTarget = romanKhataMatch[1].trim().replace(/^(show|search|check|find|please)\s+/i, '');
    const mapped = mapCandidateNameToPair(rawTarget);
    return {
      intent: 'SEARCH_ACCOUNT',
      target_name: mapped.englishName,
      raw_text: clean,
    };
  }

  // 2. "khata dikhao Ali", "show balance for Rahul", "search Usman"
  const searchPrefixMatch = clean.match(
    /(?:search|find|show\s+balance|check\s+balance|show\s+khata|view\s+ledger|open\s+khata|khata\s+dikhao|hisab\s+dikhao|balance\s+dikhao)\s+(?:for|of)?\s*([a-zA-Z\u0600-\u06FF\s]{2,25})/i
  );
  if (searchPrefixMatch && searchPrefixMatch[1]) {
    const rawTarget = searchPrefixMatch[1].trim().replace(/\s+(dikhao|dekho|karo|hai|please)$/i, '');
    const mapped = mapCandidateNameToPair(rawTarget);
    return {
      intent: 'SEARCH_ACCOUNT',
      target_name: mapped.englishName,
      raw_text: clean,
    };
  }

  // 3. Urdu: "علی کا کھاتہ دکھاؤ", "عثمان کا حساب", "راہول کا بیلنس", "طارق کا کھاتہ"
  const urduKhataMatch = clean.match(
    /(?:^|\s)([\u0600-\u06FF\w\s]{2,20}?)\s+کا\s+(?:کھاتہ|حساب|بیلنس|ریکارڈ)/
  );
  if (urduKhataMatch && urduKhataMatch[1]) {
    const rawTarget = urduKhataMatch[1].trim();
    const mapped = mapCandidateNameToPair(rawTarget);
    return {
      intent: 'SEARCH_ACCOUNT',
      target_name: mapped.englishName,
      raw_text: clean,
    };
  }

  // 4. Urdu: "کھاتہ دکھاؤ علی کا", "بیلنس چیک کرو عمر کا"
  const urduPrefixMatch = clean.match(
    /(?:کھاتہ|حساب|بیلنس|تلاش|سرچ)\s+(?:دکھاؤ|دیکھو|چیک کرو|کھولو)?\s*([\u0600-\u06FF\w\s]{2,20})/
  );
  if (urduPrefixMatch && urduPrefixMatch[1]) {
    const rawTarget = urduPrefixMatch[1].replace(/کا$|کی$|کو$/, '').trim();
    const mapped = mapCandidateNameToPair(rawTarget);
    return {
      intent: 'SEARCH_ACCOUNT',
      target_name: mapped.englishName,
      raw_text: clean,
    };
  }

  // Default: ADD_TRANSACTION
  const candidate = extractCustomerNameCandidate(clean);
  return {
    intent: 'ADD_TRANSACTION',
    target_name: candidate.englishName,
    raw_text: clean,
  };
}

/**
 * Local Rule-based Multi-Item Transaction Parser
 * Breaks down multiple statements into separate transaction objects.
 * Calculates arithmetic operations within individual phrases if present.
 * Identifies person/category names, final amounts, and types (CREDIT or DEBIT).
 */
export function parseMultiTransactionsLocal(transcript: string): MultiTransactionParseResponse {
  const clean = transcript.trim();
  if (!clean) return { transactions: [] };

  // Split on conjunctions and phrase separators
  // "aur", "اور", "and", "phir", "پھر", ",", "،", ";", "\n"
  const segments = clean
    .split(/\s+(?:aur|اور|and|phir|پھر)\s+|[،,;\n]+/gi)
    .map((s) => s.trim())
    .filter((s) => s.length > 2);

  const transactions: ExtractedTransaction[] = [];

  for (const seg of segments) {
    const amount = parseUrduNumber(seg);
    if (amount && amount > 0) {
      const candidate = extractCustomerNameCandidate(seg);
      const type = parseTransactionType(seg).type;
      if (candidate && candidate.englishName) {
        transactions.push({
          account_name: candidate.englishName,
          amount,
          type,
        });
      }
    }
  }

  // If splitting produced multiple valid transactions, return them
  if (transactions.length > 1) {
    return { transactions };
  }

  // Otherwise, fallback to single transaction extraction on the entire input
  const singleAmount = parseUrduNumber(clean) || 0;
  const singleCandidate = extractCustomerNameCandidate(clean);
  const singleType = parseTransactionType(clean).type;

  return {
    transactions: [
      {
        account_name: singleCandidate.englishName || 'کسٹمر',
        amount: singleAmount,
        type: singleType,
      },
    ],
  };
}

/**
 * Comprehensive Voice Command Processor
 * Unifies Intent Classification + Multi-Item Parser + Arithmetic & DB Resolution
 */
export function parseVoiceCommandComprehensive(
  transcript: string,
  existingCustomers: Customer[],
  groqMulti?: MultiTransactionParseResponse | null,
  groqIntent?: VoiceIntentClassification | null
): MultiVoiceParseResult {
  const clean = transcript.trim();

  // 1. Determine Intent (Groq AI classification takes precedence, local fallback)
  const intentData: VoiceIntentClassification =
    groqIntent && groqIntent.intent
      ? groqIntent
      : classifyVoiceIntentLocal(clean);

  // If intent is SEARCH_ACCOUNT:
  if (intentData.intent === 'SEARCH_ACCOUNT') {
    const targetName = intentData.target_name || '';
    const mapped = mapCandidateNameToPair(targetName);
    const matchedSearchCustomer = matchCustomerInDb(
      mapped.urduName,
      mapped.englishName,
      existingCustomers
    );

    return {
      intent: 'SEARCH_ACCOUNT',
      targetName: matchedSearchCustomer ? matchedSearchCustomer.name : mapped.englishName,
      matchedSearchCustomer,
      transactions: [],
      rawText: clean,
    };
  }

  // 2. ADD_TRANSACTION: Parse multi-item transactions
  const multiData: MultiTransactionParseResponse =
    groqMulti && groqMulti.transactions && groqMulti.transactions.length > 0
      ? groqMulti
      : parseMultiTransactionsLocal(clean);

  const parsedItems: VoiceParseResult[] = multiData.transactions.map((item) => {
    const mapped = mapCandidateNameToPair(item.account_name);
    const matchedCustomer = matchCustomerInDb(mapped.urduName, mapped.englishName, existingCustomers);
    return {
      customerName: matchedCustomer ? matchedCustomer.name : mapped.englishName,
      customerNameUrdu: matchedCustomer ? matchedCustomer.nameUrdu : mapped.urduName,
      amount: item.amount,
      type: item.type,
      rawText: clean,
      matchedCustomer,
      exists: !!matchedCustomer,
      notes: `Voice Udhaar: "${clean}"`,
    };
  });

  // Ensure at least one item
  if (parsedItems.length === 0) {
    const single = parseUrduVoiceCommand(clean, existingCustomers);
    parsedItems.push(single);
  }

  return {
    intent: 'ADD_TRANSACTION',
    transactions: parsedItems,
    rawText: clean,
  };
}

// =========================================
// ADVANCED MULTILINGUAL VOICE ENGINE
// Number Construction & Math Logic, Entity Matching & Merging
// =========================================

// Positional base unit multipliers
const POSITIONAL_MULTIPLIERS: Record<string, number> = {
  'crore': 10000000,
  'کروڑ': 10000000,
  'करोड़': 10000000,
  'million': 1000000,
  'ملین': 1000000,
  'lakh': 100000,
  'lac': 100000,
  'لاکھ': 100000,
  'लाख': 100000,
  'thousand': 1000,
  'hazaar': 1000,
  'hazar': 1000,
  'ہزار': 1000,
  'हजार': 1000,
  'hundred': 100,
  'sau': 100,
  'سو': 100,
  'सौ': 100,
};

// Word-to-number vocabulary for English, Urdu, Hindi, Roman Urdu
const VOCAB_NUMBERS: Record<string, number> = {
  // English
  'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
  'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
  'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
  'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19, 'twenty': 20,
  'thirty': 30, 'forty': 40, 'fifty': 50, 'sixty': 60, 'seventy': 70,
  'eighty': 80, 'ninety': 90,
  // Urdu script
  'صفر': 0, 'ایک': 1, 'دو': 2, 'تین': 3, 'چار': 4, 'پانچ': 5,
  'چھ': 6, 'سات': 7, 'آٹھ': 8, 'نو': 9, 'دس': 10,
  'گیارہ': 11, 'بارہ': 12, 'تیرہ': 13, 'چودہ': 14, 'پندرہ': 15,
  'سولہ': 16, 'سترہ': 17, 'اٹھارہ': 18, 'انیس': 19, 'بیس': 20,
  'پچیس': 25, 'تیس': 30, 'پینتیس': 35, 'چالیس': 40, 'پینتالیس': 45,
  'پچاس': 50, 'ساٹھ': 60, 'ستر': 70, 'اسی': 80, 'نوے': 90,
  // Hindi Devanagari script
  'शून्य': 0, 'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4, 'पांच': 5,
  'छह': 6, 'सात': 7, 'आठ': 8, 'नौ': 9, 'दस': 10,
  'ग्यारह': 11, 'बारह': 12, 'तेरह': 13, 'चौदह': 14, 'पंद्रह': 15,
  'सोलह': 16, 'सत्रह': 17, 'अट्ठारह': 18, 'उन्नीस': 19, 'बीस': 20,
  'पच्चीस': 25, 'तीस': 30, 'पैंतीस': 35, 'चालीस': 40, 'पैंतालीस': 45,
  'पचास': 50, 'साठ': 60, 'सत्तर': 70, 'अस्सी': 80, 'नब्बे': 90,
  // Roman Urdu / Hindi
  'ek': 1, 'aik': 1, 'do': 2, 'teen': 3, 'char': 4, 'chaar': 4,
  'paanch': 5, 'panch': 5, 'che': 6, 'chey': 6, 'chheh': 6, 'saat': 7, 'aath': 8, 'ath': 8,
  'nau': 9, 'das': 10, 'gyarah': 11, 'barah': 12, 'terah': 13, 'chaudah': 14,
  'pandrah': 15, 'solah': 16, 'satrah': 17, 'atharah': 18, 'unnees': 19,
  'bees': 20, 'pachees': 25, 'tees': 30, 'paintees': 35, 'chalees': 40,
  'paintalees': 45, 'pachas': 50, 'saath': 60, 'sattar': 70, 'assi': 80, 'nawwe': 90,
};

/**
 * Safe Mathematical Expression Evaluator with Operator Precedence (*, / before +, -)
 */
export function evaluateMathExpression(expr: string): number {
  if (!expr) return 0;
  const sanitized = expr.replace(/[^0-9+\-*/. ]/g, '').trim();
  if (!sanitized) return 0;

  const rawTokens = sanitized.match(/\d+(?:\.\d+)?|[+\-*/]/g);
  if (!rawTokens || rawTokens.length === 0) return 0;

  const tokens: (number | string)[] = [];
  for (const t of rawTokens) {
    if (['+', '-', '*', '/'].includes(t)) {
      tokens.push(t);
    } else {
      tokens.push(parseFloat(t) || 0);
    }
  }

  // First pass: multiplication and division (*, /)
  const intermediate: (number | string)[] = [];
  let i = 0;
  while (i < tokens.length) {
    const token = tokens[i];
    if (token === '*' || token === '/') {
      const prev = intermediate.pop();
      const next = tokens[i + 1];
      if (typeof prev === 'number' && typeof next === 'number') {
        const val = token === '*' ? prev * next : (next !== 0 ? prev / next : 0);
        intermediate.push(val);
        i += 2;
      } else {
        intermediate.push(token);
        i++;
      }
    } else {
      intermediate.push(token);
      i++;
    }
  }

  // Second pass: addition and subtraction (+, -)
  if (intermediate.length === 0) return 0;
  let result = typeof intermediate[0] === 'number' ? (intermediate[0] as number) : 0;
  let j = 1;
  while (j < intermediate.length) {
    const op = intermediate[j];
    const next = intermediate[j + 1];
    if (typeof next === 'number') {
      if (op === '+') result += next;
      else if (op === '-') result -= next;
    }
    j += 2;
  }

  return Math.round(result * 100) / 100;
}

/**
 * Parses a segment of words using the Positional & Cumulative Value Algorithm
 * Handles additive & multiplicative stacking (e.g., "2 lakh 50 hazar" -> 250,000)
 */
export function parsePositionalNumberSegment(text: string): number | null {
  if (!text) return null;

  // Replace Urdu/Arabic digits first
  let norm = text;
  for (const [urChar, latChar] of Object.entries(URDU_DIGITS_MAP)) {
    norm = norm.split(urChar).join(latChar);
  }

  // Direct digits test (e.g., "500", "1200")
  const directDigits = norm.match(/^\s*(\d+(?:\.\d+)?)\s*$/);
  if (directDigits) {
    return parseFloat(directDigits[1]);
  }

  const words = norm.toLowerCase().split(/[\s,]+/);
  let total = 0;
  let currentSegment = 0;
  let hasNumber = false;

  for (let i = 0; i < words.length; i++) {
    const w = words[i].trim();
    if (!w) continue;

    // Check if word is digit sequence (e.g. "2", "50", "500")
    if (/^\d+(?:\.\d+)?$/.test(w)) {
      currentSegment = parseFloat(w);
      hasNumber = true;
      continue;
    }

    // Check if word is in vocabulary numbers (e.g., "do", "pachas", "two", "دو")
    if (VOCAB_NUMBERS[w] !== undefined) {
      currentSegment = VOCAB_NUMBERS[w];
      hasNumber = true;
      continue;
    }

    // Check if word is positional multiplier (e.g., "lakh", "hazar", "thousand", "hundred")
    if (POSITIONAL_MULTIPLIERS[w] !== undefined) {
      const mult = POSITIONAL_MULTIPLIERS[w];
      hasNumber = true;
      if (currentSegment === 0) {
        currentSegment = 1;
      }
      total += currentSegment * mult;
      currentSegment = 0;
      continue;
    }
  }

  total += currentSegment;
  return hasNumber && total > 0 ? total : null;
}

/**
 * Parses mathematical speech input into exact expressions and calculated results
 * Maps operators (+, -, *, /) and stacks numbers positionally
 */
export function parseMathematicalSpeech(text: string): {
  expression: string;
  result: number;
  hasMathOperators: boolean;
} {
  if (!text) return { expression: '', result: 0, hasMathOperators: false };

  // Replace Urdu/Arabic digits
  let norm = text;
  for (const [urChar, latChar] of Object.entries(URDU_DIGITS_MAP)) {
    norm = norm.split(urChar).join(latChar);
  }

  // Map operator words to symbols
  norm = norm
    .replace(/\b(?:plus|add|jama|جمع|jodo|jod|जोड़|जोड़ो|\+)\b/gi, ' + ')
    .replace(/\b(?:minus|subtract|manfi|منفی|ghatao|kam|घटाओ|\-)\b/gi, ' - ')
    .replace(/\b(?:multiply|multiplied by|times|zarb|ضرب|guna|into|गुणा|\*)\b/gi, ' * ')
    .replace(/\b(?:divided by|divide|taqseem|تقسیم|bhag|भाग|\/)\b/gi, ' / ');

  const hasMathOperators = /[+\-*/]/.test(norm);

  // Split by operators
  const parts = norm.split(/([+\-*/])/);
  const exprTokens: string[] = [];

  for (const part of parts) {
    const trimmed = part.trim();
    if (['+', '-', '*', '/'].includes(trimmed)) {
      exprTokens.push(trimmed);
    } else if (trimmed) {
      const num = parsePositionalNumberSegment(trimmed) ?? parseUrduNumber(trimmed);
      if (num !== null) {
        exprTokens.push(String(num));
      }
    }
  }

  if (exprTokens.length === 0) {
    const fallbackNum = parseUrduNumber(text) || 0;
    return {
      expression: String(fallbackNum),
      result: fallbackNum,
      hasMathOperators: false,
    };
  }

  // Ensure expression doesn't end with an operator
  while (exprTokens.length > 0 && ['+', '-', '*', '/'].includes(exprTokens[exprTokens.length - 1])) {
    exprTokens.pop();
  }

  const expression = exprTokens.join(' ');
  const result = evaluateMathExpression(expression);

  return {
    expression,
    result,
    hasMathOperators: exprTokens.some((t) => ['+', '-', '*', '/'].includes(t)),
  };
}

/**
 * Entity Matching & Merging:
 * Compares candidate account name with existing accounts list.
 * If matched or close variation/fuzzy match, sets is_existing_account: true
 * and strictly maps to that target account to prevent duplicates!
 */
export function matchExistingAccount(
  spokenName: string,
  existingCustomers: Customer[]
): {
  matchedCustomer: Customer | null;
  isExisting: boolean;
  resolvedName: string;
} {
  if (!spokenName.trim()) {
    return { matchedCustomer: null, isExisting: false, resolvedName: '' };
  }

  const clean = spokenName.trim().toLowerCase();
  const cleanNorm = normalizeUrdu(clean);

  for (const cust of existingCustomers) {
    const custNameLower = cust.name.toLowerCase().trim();
    const custUrduNorm = normalizeUrdu(cust.nameUrdu.toLowerCase().trim());

    // 1. Exact match in English or Urdu
    if (custNameLower === clean || custUrduNorm === cleanNorm) {
      return { matchedCustomer: cust, isExisting: true, resolvedName: cust.name };
    }

    // 2. Substring containment match (e.g. "Ali" in "Ali Khan" or vice versa)
    if (
      (clean.length >= 3 && custNameLower.includes(clean)) ||
      (custNameLower.length >= 3 && clean.includes(custNameLower)) ||
      (cleanNorm.length >= 3 && custUrduNorm.includes(cleanNorm)) ||
      (custUrduNorm.length >= 3 && cleanNorm.includes(custUrduNorm))
    ) {
      return { matchedCustomer: cust, isExisting: true, resolvedName: cust.name };
    }

    // 3. Dictionary translation matching (e.g., Ali <-> علی)
    const mappedEn = URDU_NAME_MAPPINGS[cleanNorm];
    if (mappedEn && mappedEn.toLowerCase() === custNameLower) {
      return { matchedCustomer: cust, isExisting: true, resolvedName: cust.name };
    }
    const mappedUr = ENGLISH_TO_URDU_MAP[clean];
    if (mappedUr && normalizeUrdu(mappedUr) === custUrduNorm) {
      return { matchedCustomer: cust, isExisting: true, resolvedName: cust.name };
    }
  }

  // If no match in existing list: return clean formatted candidate name
  const mapped = mapCandidateNameToPair(spokenName);
  return {
    matchedCustomer: null,
    isExisting: false,
    resolvedName: mapped.englishName,
  };
}

/**
 * Advanced Multilingual Voice Engine Coordinator
 * Handles Voice Calculations and Ledger Transactions according to the exact JSON specifications:
 * - mode: LEDGER or CALCULATOR
 * - ledger_data: account_name, is_existing_account, amount, type
 * - calculator_data: expression, result
 * - raw_text
 */
export function parseVoiceEngineCommand(
  rawText: string,
  existingCustomers: Customer[],
  groqEngineResponse?: VoiceEngineResponse | null
): VoiceEngineResponse {
  const clean = rawText.trim();

  // 1. If Groq Voice Engine response was provided, validate entity matching against DB
  if (groqEngineResponse && groqEngineResponse.mode) {
    if (groqEngineResponse.mode === 'LEDGER' && groqEngineResponse.ledger_data) {
      const match = matchExistingAccount(
        groqEngineResponse.ledger_data.account_name,
        existingCustomers
      );
      return {
        mode: 'LEDGER',
        ledger_data: {
          account_name: match.isExisting ? match.resolvedName : groqEngineResponse.ledger_data.account_name,
          is_existing_account: match.isExisting,
          amount: groqEngineResponse.ledger_data.amount,
          type: groqEngineResponse.ledger_data.type,
        },
        calculator_data: groqEngineResponse.calculator_data,
        raw_text: clean,
      };
    }
    return {
      ...groqEngineResponse,
      raw_text: clean,
    };
  }

  // 2. Local Voice Engine parsing
  // Step A: Parse mathematical speech
  const mathData = parseMathematicalSpeech(clean);

  // Step B: Transaction type mapping
  const txType = parseTransactionType(clean);

  // Step C: Entity extraction (check if a person/business name exists)
  const candidate = extractCustomerNameCandidate(clean);
  const candidateName = candidate.englishName || candidate.urduName;
  const matchedAccount = candidateName
    ? matchExistingAccount(candidateName, existingCustomers)
    : { matchedCustomer: null, isExisting: false, resolvedName: '' };

  // Step D: Detect mode (LEDGER vs CALCULATOR)
  // Has account name OR transaction keywords ("diye", "liya", "milay", "bheje", "credit", "debit", "روپے", etc.)
  const isLedgerMode =
    Boolean(matchedAccount.resolvedName) ||
    Boolean(matchedAccount.isExisting) ||
    Boolean(txType.matchedKeyword);

  if (isLedgerMode) {
    const finalAmount = mathData.result > 0 ? mathData.result : (parseUrduNumber(clean) || 0);
    const accountName = matchedAccount.isExisting
      ? matchedAccount.resolvedName
      : (matchedAccount.resolvedName || candidateName || 'Unknown');

    return {
      mode: 'LEDGER',
      ledger_data: {
        account_name: accountName,
        is_existing_account: matchedAccount.isExisting,
        amount: finalAmount,
        type: txType.type,
      },
      calculator_data: mathData.hasMathOperators
        ? {
            expression: mathData.expression,
            result: mathData.result,
          }
        : {
            expression: String(finalAmount),
            result: finalAmount,
          },
      raw_text: clean,
    };
  }

  // CALCULATOR Mode: Pure mathematical calculation
  return {
    mode: 'CALCULATOR',
    ledger_data: null,
    calculator_data: {
      expression: mathData.expression || '0',
      result: mathData.result,
    },
    raw_text: clean,
  };
}

