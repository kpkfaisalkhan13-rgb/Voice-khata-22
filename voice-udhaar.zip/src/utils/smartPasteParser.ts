import { Customer, SmartPasteParsedEntry, SmartPasteType } from '../types';
import { dbService } from '../services/db';
import { normalizeUrdu, URDU_NAME_MAPPINGS, ENGLISH_TO_URDU_MAP } from './urduParser';

// Map Eastern Arabic, Urdu, and Devanagari numerals to Latin 0-9
const DIGITS_MAP: Record<string, string> = {
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
};

// Word-to-number mapping covering English, Urdu, Roman Urdu, and Hindi
const NUM_WORDS: Record<string, number> = {
  // English 0-90
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19,
  twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90,

  // Urdu script
  'صفر': 0, 'ایک': 1, 'دو': 2, 'تین': 3, 'چار': 4, 'پانچ': 5, 'چھ': 6, 'سات': 7, 'آٹھ': 8, 'نو': 9, 'دس': 10,
  'گیارہ': 11, 'بارہ': 12, 'تیرہ': 13, 'چودہ': 14, 'پندرہ': 15, 'سولہ': 16, 'سترہ': 17, 'اٹھارہ': 18, 'انیس': 19,
  'بیس': 20, 'اکیس': 21, 'بائیس': 22, 'تیئیس': 23, 'چوبیس': 24, 'پچیس': 25, 'چھبیس': 26, 'ستائیس': 27, 'اٹھائیس': 28, 'انتیس': 29,
  'تیس': 30, 'چالیس': 40, 'پچاس': 50, 'ساٹھ': 60, 'ستر': 70, 'اسی': 80, 'نوے': 90,

  // Hindi Devanagari
  'शून्य': 0, 'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4, 'पांच': 5, 'पाँच': 5, 'छह': 6, 'सात': 7, 'आठ': 8, 'नौ': 9, 'दस': 10,
  'ग्यारह': 11, 'बारह': 12, 'तेरह': 13, 'चौदह': 14, 'पंद्रह': 15, 'सोलह': 16, 'सत्रह': 17, 'अठारह': 18, 'उन्नीस': 19,
  'बीस': 20, 'पच्चीस': 25, 'तीस': 30, 'चालीस': 40, 'पचास': 50, 'साठ': 60, 'सत्तर': 70, 'अस्सी': 80, 'नब्बे': 90,

  // Roman Urdu / Hindi
  ek: 1, aik: 1, do: 2, teen: 3, char: 4, chaar: 4, panch: 5, paanch: 5, che: 6, chey: 6, saat: 7, aath: 8, ath: 8,
  nau: 9, no: 9, das: 10, gyarah: 11, barah: 12, terah: 13, chaudah: 14, pandrah: 15, solah: 16, satrah: 17,
  atharah: 18, unnees: 19, unnis: 19, bees: 20, pachees: 25, tees: 30, chalis: 40, chalees: 40,
  pachas: 50, saath: 60, sath: 60, sattar: 70, assi: 80, nawwe: 90,
};

/**
 * 1. CORE PARSER LOGIC - parseAmount(text):
 * Must understand:
 * - English: "ten hundred = 1000", "one hundred twelve dollars = 112", "Alex ten hundred"
 * - Urdu Roman: "panch hazar = 5000", "saade paanch hazar = 5500", "19 hazar = 19000"
 * - Urdu Script: "پانچ ہزار = 5000", "علی پانچ ہزار جمع"
 * - Hindi: "पाँच हज़ार = 5000"
 *
 * Strict Rule: Never convert to dollar or exchange rate. 19 hazar means 19000.
 */
export function parseAmount(text: string): { amount: number; learnedCorrectionApplied: boolean } {
  if (!text) return { amount: 0, learnedCorrectionApplied: false };

  // Step 0: Check Self-Learning Dictionary first!
  const learned = dbService.findSelfLearningCorrection(text);
  if (learned) {
    const val = parseFloat(learned.correct);
    if (!isNaN(val) && val > 0) {
      return { amount: val, learnedCorrectionApplied: true };
    }
  }

  // Also check UserVoiceCorrections table
  const voiceCorr = dbService.findVoiceCorrection(text);
  if (voiceCorr && voiceCorr.corrected_number > 0) {
    return { amount: voiceCorr.corrected_number, learnedCorrectionApplied: true };
  }

  let s = text.trim();

  // Normalize native digits
  for (const [u, d] of Object.entries(DIGITS_MAP)) {
    s = s.split(u).join(d);
  }

  // Pre-clean punctuation (keep dots in numbers, remove commas)
  s = s.replace(/,/g, '');
  const lower = s.toLowerCase();

  // Check fraction multipliers first:
  // "saade paanch hazar", "saadhe panch hazar", "ساڑھے پانچ ہزار", "साढ़े पाँच हज़ार" -> 5500
  const saadeMatch = lower.match(/(?:saade|saadhe|sadhe|ساڑھے|साढ़े)\s+([a-z\u0600-\u06FF\u0900-\u097F]+)\s+(?:hazar|hazaar|ہزار|हजार|हज़ार|thousand)/i);
  if (saadeMatch) {
    const word = saadeMatch[1].trim();
    const base = NUM_WORDS[word] ?? parseFloat(word);
    if (base) {
      return { amount: Math.round((base + 0.5) * 1000), learnedCorrectionApplied: false };
    }
  }

  // "paune panch hazar", "پونے پانچ ہزار", "पौने पाँच हज़ार" -> 4750
  const pauneMatch = lower.match(/(?:paune|pone|پونے|पौने)\s+([a-z\u0600-\u06FF\u0900-\u097F]+)\s+(?:hazar|hazaar|ہزار|हजार|हज़ार|thousand)/i);
  if (pauneMatch) {
    const word = pauneMatch[1].trim();
    const base = NUM_WORDS[word] ?? parseFloat(word);
    if (base) {
      return { amount: Math.round((base - 0.25) * 1000), learnedCorrectionApplied: false };
    }
  }

  // "sawa panch hazar", "سوا پانچ ہزار", "सवा पाँच हज़ार" -> 5250
  const sawaMatch = lower.match(/(?:sawa|سوا|सवा)\s+([a-z\u0600-\u06FF\u0900-\u097F]+)\s+(?:hazar|hazaar|ہزار|हजार|हज़ार|thousand)/i);
  if (sawaMatch) {
    const word = sawaMatch[1].trim();
    const base = NUM_WORDS[word] ?? parseFloat(word);
    if (base) {
      return { amount: Math.round((base + 0.25) * 1000), learnedCorrectionApplied: false };
    }
  }

  // "dhai hazar", "ڈھائی ہزار", "ढाई हज़ार" -> 2500
  if (/(?:dhai|ڈھائی|ढाई)\s*(?:hazar|hazaar|ہزار|हजार|हज़ार|thousand)/i.test(lower)) {
    return { amount: 2500, learnedCorrectionApplied: false };
  }

  // "dedh hazar", "ڈیڑھ ہزار", "डेढ़ हज़ार" -> 1500
  if (/(?:dedh|ڈیڑھ|डेढ़)\s*(?:hazar|hazaar|ہزار|हजार|हज़ार|thousand)/i.test(lower)) {
    return { amount: 1500, learnedCorrectionApplied: false };
  }

  // English positional patterns:
  // "ten hundred" -> 1000, "fifteen hundred" -> 1500, "twenty hundred" -> 2000
  const hundredCompoundMatch = lower.match(/\b([a-z0-9]+)\s+hundred\b/i);
  if (hundredCompoundMatch) {
    const word = hundredCompoundMatch[1].trim();
    const multiplier = NUM_WORDS[word] ?? parseFloat(word);
    if (multiplier) {
      let total = multiplier * 100;
      // check remainder after "hundred" e.g. "one hundred twelve" or "ten hundred twenty"
      const remainder = lower.substring(lower.indexOf('hundred') + 7).trim();
      const remNum = parseSimpleEnglishWords(remainder);
      if (remNum > 0) {
        total += remNum;
      }
      return { amount: Math.round(total), learnedCorrectionApplied: false };
    }
  }

  // "19 hazar" / "19 thousand" / "panch hazar" / "پانچ ہزار" / "पाँच हज़ार"
  const hazarCompoundMatch = lower.match(/(?:^|[^\p{L}\p{N}])([a-z0-9\u0600-\u06FF\u0900-\u097F]+)\s*(?:hazar|hazaar|ہزار|हजार|हज़ार|thousand|\bk\b)(?:[^\p{L}\p{N}]|$)/iu);
  if (hazarCompoundMatch) {
    const word = hazarCompoundMatch[1].trim();
    const multiplier = NUM_WORDS[word] ?? parseFloat(word);
    if (multiplier) {
      let total = multiplier * 1000;
      return { amount: Math.round(total), learnedCorrectionApplied: false };
    }
  }

  // "lakh" / "لاکھ" / "लाख"
  const lakhMatch = lower.match(/(?:^|[^\p{L}\p{N}])([a-z0-9\u0600-\u06FF\u0900-\u097F]+)\s*(?:lakh|lac|لاکھ|लाख)(?:[^\p{L}\p{N}]|$)/iu);
  if (lakhMatch) {
    const word = lakhMatch[1].trim();
    const multiplier = NUM_WORDS[word] ?? parseFloat(word);
    if (multiplier) {
      return { amount: Math.round(multiplier * 100000), learnedCorrectionApplied: false };
    }
  }

  // "crore" / "کروڑ" / "करोड़"
  const croreMatch = lower.match(/(?:^|[^\p{L}\p{N}])([a-z0-9\u0600-\u06FF\u0900-\u097F]+)\s*(?:crore|کروڑ|करोड़)(?:[^\p{L}\p{N}]|$)/iu);
  if (croreMatch) {
    const word = croreMatch[1].trim();
    const multiplier = NUM_WORDS[word] ?? parseFloat(word);
    if (multiplier) {
      return { amount: Math.round(multiplier * 10000000), learnedCorrectionApplied: false };
    }
  }

  // Direct digits search (e.g. 5000, 3000, 10220)
  // Ensure we don't accidentally match phone numbers or list numbers like "1."
  const digitMatches = lower.match(/\b\d+(?:\.\d+)?\b/g);
  if (digitMatches && digitMatches.length > 0) {
    // If the first digit was a list index (e.g. 1. or 2) followed by a larger amount, pick the larger amount
    for (let i = digitMatches.length - 1; i >= 0; i--) {
      const val = parseFloat(digitMatches[i]);
      if (val >= 10 || digitMatches.length === 1) {
        return { amount: Math.round(val), learnedCorrectionApplied: false };
      }
    }
    return { amount: parseFloat(digitMatches[0]), learnedCorrectionApplied: false };
  }

  // Plain word parser from dictionary (e.g. "one hundred twelve" or "panch hazar")
  const wordAmount = parseSimpleEnglishWords(lower);
  if (wordAmount > 0) {
    return { amount: wordAmount, learnedCorrectionApplied: false };
  }

  return { amount: 0, learnedCorrectionApplied: false };
}

/**
 * Helper to parse sequences of spoken English number words like:
 * "one hundred twelve" -> 112
 * "two thousand five hundred" -> 2500
 */
function parseSimpleEnglishWords(text: string): number {
  if (!text) return 0;
  // Clean out currency words (dollar, dollars, rupees, pkr, inr, etc.)
  const clean = text
    .replace(/\b(?:dollars?|rupees?|rs|pkr|inr|usd|bucks?|روپے|رقم)\b/gi, ' ')
    .trim();

  const tokens = clean.toLowerCase().split(/[\s,+-]+/);
  let total = 0;
  let current = 0;
  let matchedAny = false;

  for (const t of tokens) {
    if (!t) continue;
    if (t === 'and') continue;

    if (t === 'thousand' || t === 'hazar' || t === 'hazaar') {
      matchedAny = true;
      if (current === 0) current = 1;
      total += current * 1000;
      current = 0;
      continue;
    }

    if (t === 'hundred' || t === 'sau') {
      matchedAny = true;
      if (current === 0) current = 1;
      current = current * 100;
      continue;
    }

    if (t === 'lakh' || t === 'lac') {
      matchedAny = true;
      if (current === 0) current = 1;
      total += current * 100000;
      current = 0;
      continue;
    }

    const n = NUM_WORDS[t] ?? (parseFloat(t) || null);
    if (n !== null) {
      matchedAny = true;
      current += n;
    }
  }

  total += current;
  return matchedAny ? total : 0;
}

/**
 * Detect transaction type from entry text
 * Jama (Credit / جمع / وصول) vs Udhaar (Debit / ادھار / دیا)
 */
export function parseTransactionTypeFromText(text: string): SmartPasteType {
  const lower = text.toLowerCase();
  const normalized = normalizeUrdu(lower);

  // Jama (Credit / Received / Deposit)
  if (
    lower.includes('jama') ||
    lower.includes('credit') ||
    lower.includes('wasool') ||
    lower.includes('milay') ||
    lower.includes('miley') ||
    lower.includes('mila') ||
    lower.includes('liya') ||
    lower.includes('received') ||
    lower.includes('got') ||
    normalized.includes('جمع') ||
    normalized.includes('وصول') ||
    normalized.includes('ملے') ||
    normalized.includes('ملا') ||
    lower.includes('जमा') ||
    lower.includes('वसूली')
  ) {
    return 'Jama';
  }

  // Udhaar (Debit / Lent / Given / Borrowed)
  if (
    lower.includes('udhaar') ||
    lower.includes('udhar') ||
    lower.includes('debit') ||
    lower.includes('diye') ||
    lower.includes('diya') ||
    lower.includes('qarz') ||
    lower.includes('bheje') ||
    lower.includes('give') ||
    lower.includes('gave') ||
    normalized.includes('ادھار') ||
    normalized.includes('دیے') ||
    normalized.includes('دیا') ||
    normalized.includes('قرض') ||
    lower.includes('उधार') ||
    lower.includes('दिए') ||
    lower.includes('दिया')
  ) {
    return 'Udhaar';
  }

  // Default in Khata ledger when unspecified is Udhaar
  return 'Udhaar';
}

/**
 * Extract Name from a single entry string:
 * E.g., "Ali 5000 Jama" -> "Ali"
 * "Alex ten hundred" -> "Alex"
 * "علی پانچ ہزار جمع" -> "علی"
 * "Ahmed 3000 Udhaar" -> "Ahmed"
 * "1. Ali - 5000 (Jama)" -> "Ali"
 */
export function extractNameFromEntry(text: string, existingCustomers: Customer[] = []): string {
  let clean = text.trim();

  // Strip leading list enumeration like "1.", "2)", "•", "-", "*"
  clean = clean.replace(/^[\d]+[\.\)\-:]\s*/, '').replace(/^[\*\-\•\–]\s*/, '').trim();

  // 1. Check if an existing customer name is present
  for (const c of existingCustomers) {
    const cNameLower = c.name.toLowerCase();
    const cUrdu = c.nameUrdu ? c.nameUrdu.trim() : '';

    if (clean.toLowerCase().includes(cNameLower)) {
      return c.name;
    }
    if (cUrdu && clean.includes(cUrdu)) {
      return c.nameUrdu || c.name;
    }
  }

  // 2. Transliteration dictionaries
  for (const [ur, en] of Object.entries(URDU_NAME_MAPPINGS)) {
    if (clean.includes(ur)) return en;
    if (clean.toLowerCase().includes(en.toLowerCase())) return en;
  }

  // 3. Fallback: Parse the tokens before numbers or action keywords
  // E.g. "Kashif 5000 Jama" or "Kashif : 5000"
  const colonParts = clean.split(/[:=\-–]/);
  if (colonParts.length > 1 && colonParts[0].trim().length >= 2) {
    const candidate = colonParts[0].trim().replace(/[^a-zA-Z\u0600-\u06FF\u0900-\u097F\s]/g, '').trim();
    if (candidate && !['name', 'khata', 'naam', 'گاہک', 'کسٹمر'].includes(candidate.toLowerCase())) {
      return candidate;
    }
  }

  // Match words at the beginning of the line before digits or numbers
  const words = clean.split(/\s+/);
  const nameTokens: string[] = [];

  const stopWords = new Set([
    'jama', 'udhaar', 'udhar', 'credit', 'debit', 'rupay', 'rupees', 'rs', 'pkr', 'inr', 'dollar', 'dollars',
    'hazar', 'hazaar', 'hundred', 'thousand', 'lakh', 'lac', 'crore',
    'جمع', 'ادھار', 'دیے', 'دیا', 'وصول', 'روپے', 'ہزار', 'سو', 'لاکھ', 'کروڑ',
    'जमा', 'उधार', 'रुपये', 'हजार', 'हज़ार', 'लाख', 'करोड़', 'सौ',
    'ko', 'ne', 'se', 'ka', 'ke', 'ki', 'کو', 'نے', 'سے', 'کا', 'کے', 'کی', 'from', 'to', 'for'
  ]);

  for (const w of words) {
    const wNorm = w.toLowerCase().replace(/[,.:;'"()]/g, '');
    // If it's a digit or number word or stop word, break
    if (/^\d+/.test(wNorm) || NUM_WORDS[wNorm] !== undefined || stopWords.has(wNorm)) {
      break;
    }
    if (wNorm.length > 0) {
      nameTokens.push(w.replace(/[,.:;'"()]/g, ''));
    }
  }

  if (nameTokens.length > 0) {
    return nameTokens.join(' ').trim();
  }

  // If no prefix name found, look at the end of the text
  // E.g. "5000 Jama Ali"
  const reversedWords = [...words].reverse();
  const trailingNameTokens: string[] = [];
  for (const w of reversedWords) {
    const wNorm = w.toLowerCase().replace(/[,.:;'"()]/g, '');
    if (/^\d+/.test(wNorm) || NUM_WORDS[wNorm] !== undefined || stopWords.has(wNorm)) {
      break;
    }
    if (wNorm.length > 0) {
      trailingNameTokens.unshift(w.replace(/[,.:;'"()]/g, ''));
    }
  }

  if (trailingNameTokens.length > 0) {
    return trailingNameTokens.join(' ').trim();
  }

  return 'Unknown';
}

/**
 * Splits raw pasted text into individual entry lines/segments.
 * Handles both newline separated lists and inline comma/semicolon separated lists:
 * "Ali 5000 Jama, Ahmed 3000 Udhaar"
 */
export function splitPasteIntoEntries(rawText: string): string[] {
  if (!rawText || !rawText.trim()) return [];

  // First split by newlines
  const rawLines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const results: string[] = [];

  for (const line of rawLines) {
    // Check if the line has multiple comma/semicolon separated entries
    // e.g. "Ali 5000 Jama, Ahmed 3000 Udhaar"
    if (line.includes(',') || line.includes(';')) {
      // Check if splitting produces segments that each have amounts or names
      const commaSegments = line
        .split(/[,;]+/)
        .map((s) => s.trim())
        .filter((s) => s.length >= 3);

      // If at least two segments have digits or number words, treat as multiple entries
      const validSubEntries = commaSegments.filter((seg) => {
        const { amount } = parseAmount(seg);
        return amount > 0;
      });

      if (validSubEntries.length >= 2) {
        results.push(...commaSegments);
        continue;
      }
    }

    results.push(line);
  }

  return results;
}

/**
 * 2. PASTE & CHECK FLOW:
 * Parses full list and matches against local DB customers.
 *
 * IF KHATA EXISTS:
 * - isExistingKhata: true
 * - isChecked: true (checked by default!)
 *
 * IF KHATA NOT FOUND:
 * - isExistingKhata: false
 * - isChecked: false (UNCHECKED by default!)
 * - Shows Red Warning Card in UI
 */
export function parseSmartPasteBatch(
  rawText: string,
  existingCustomers: Customer[]
): SmartPasteParsedEntry[] {
  const segments = splitPasteIntoEntries(rawText);
  const entries: SmartPasteParsedEntry[] = [];

  for (let i = 0; i < segments.length; i++) {
    const rawLine = segments[i].trim();
    if (!rawLine) continue;

    const { amount, learnedCorrectionApplied } = parseAmount(rawLine);
    const type = parseTransactionTypeFromText(rawLine);
    const candidateName = extractNameFromEntry(rawLine, existingCustomers);

    // Entity resolution in local DB: Does Khata exist with this name?
    const matchedCustomer = findMatchingCustomer(candidateName, existingCustomers);
    const isExistingKhata = Boolean(matchedCustomer);

    entries.push({
      id: `paste-entry-${Date.now()}-${i}-${Math.random().toString(36).substr(2, 4)}`,
      name: matchedCustomer ? (matchedCustomer.nameUrdu || matchedCustomer.name) : candidateName,
      amount,
      type,
      original_text: rawLine,
      isExistingKhata,
      customerExists: isExistingKhata,
      matchedCustomer: matchedCustomer || null,
      // Rule: Found Khata -> Checked by default.
      // Not-Found Khata -> Unchecked by default!
      isChecked: isExistingKhata,
      learnedCorrectionApplied,
    });
  }

  return entries;
}

/**
 * Match a candidate name against existing customers list
 * Handles Latin, Urdu, case-insensitive, normalized, and mapped names
 */
export function findMatchingCustomer(
  candidateName: string,
  existingCustomers: Customer[]
): Customer | null {
  if (!candidateName || !candidateName.trim() || candidateName.toLowerCase() === 'unknown') {
    return null;
  }

  const clean = candidateName.trim().toLowerCase();
  const cleanNorm = normalizeUrdu(clean);

  // 1. Exact match on name or nameUrdu
  for (const c of existingCustomers) {
    if (c.name.toLowerCase() === clean) return c;
    if (c.nameUrdu && c.nameUrdu.trim().toLowerCase() === clean) return c;
  }

  // 2. Normalized match (without tashkeel, diacritics)
  for (const c of existingCustomers) {
    const cNorm = normalizeUrdu(c.name.toLowerCase());
    const cUrduNorm = normalizeUrdu((c.nameUrdu || '').toLowerCase());
    if (cNorm === cleanNorm || (cUrduNorm && cUrduNorm === cleanNorm)) {
      return c;
    }
  }

  // 3. Transliteration mapping match (e.g. Ali <-> علی)
  for (const c of existingCustomers) {
    const mappedEn = URDU_NAME_MAPPINGS[cleanNorm] || URDU_NAME_MAPPINGS[clean];
    const mappedUr = ENGLISH_TO_URDU_MAP[clean];

    if (mappedEn && c.name.toLowerCase() === mappedEn.toLowerCase()) return c;
    if (mappedUr && c.nameUrdu && normalizeUrdu(c.nameUrdu) === normalizeUrdu(mappedUr)) return c;
  }

  // 4. Substring / Token match (e.g. "Muhammad Ali" -> "Ali")
  for (const c of existingCustomers) {
    const cNameLower = c.name.toLowerCase();
    if (cNameLower.includes(clean) || clean.includes(cNameLower)) {
      return c;
    }
    if (c.nameUrdu && (c.nameUrdu.includes(cleanNorm) || cleanNorm.includes(c.nameUrdu))) {
      return c;
    }
  }

  return null;
}
