// SQLCipher AES-256 GCM Client-side Encryption Utility using Web Crypto API

export interface EncryptedPayload {
  version: number;
  salt: string; // Base64
  iv: string;   // Base64
  data: string; // Base64 ciphertext
}

const PBKDF2_ITERATIONS = 100000;

function bufferToBase64(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToBuffer(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const passwordKey = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as unknown as ArrayBuffer,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256'
    },
    passwordKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypt arbitrary binary or text data using AES-256 GCM (SQLCipher compatible)
 */
export async function encryptData(data: Uint8Array | string, password = 'voice-udhaar-master-key'): Promise<EncryptedPayload> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(password, salt);

  const rawBytes = typeof data === 'string' ? new TextEncoder().encode(data) : data;
  const ciphertextBuffer = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as unknown as ArrayBuffer },
    key,
    rawBytes as unknown as ArrayBuffer
  );

  return {
    version: 1,
    salt: bufferToBase64(salt),
    iv: bufferToBase64(iv),
    data: bufferToBase64(new Uint8Array(ciphertextBuffer))
  };
}

/**
 * Decrypt AES-256 GCM payload
 */
export async function decryptData(payload: EncryptedPayload, password = 'voice-udhaar-master-key'): Promise<Uint8Array> {
  const salt = base64ToBuffer(payload.salt);
  const iv = base64ToBuffer(payload.iv);
  const ciphertext = base64ToBuffer(payload.data);

  const key = await deriveKey(password, salt);
  const decryptedBuffer = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: iv as unknown as ArrayBuffer },
    key,
    ciphertext as unknown as ArrayBuffer
  );

  return new Uint8Array(decryptedBuffer);
}

export async function decryptText(payload: EncryptedPayload, password = 'voice-udhaar-master-key'): Promise<string> {
  const bytes = await decryptData(payload, password);
  return new TextDecoder().decode(bytes);
}
