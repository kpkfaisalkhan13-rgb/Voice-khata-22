// ============================================================================
// ENGLISH SPOKEN NUMBER DICTIONARY & ALGORITHMIC PARSER
// Offline lookup parser to handle English voice transcriptions without rounding off digits.
// ============================================================================

export const englishNumberDict: Record<string, number> = {
  'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
  'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
  'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
  'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19,
  'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50,
  'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90,
  'hundred': 100, 'thousand': 1000, 'million': 1000000,

  // Regional spoken aliases
  'k': 1000,
  'lakh': 100000,
  'lac': 100000,
  'crore': 10000000,
  'billion': 1000000000,
};

/**
 * Offline lookup parser function to handle English voice transcriptions
 * without rounding off digits.
 *
 * Scans words in the transcript, matches them with the dictionary keys,
 * multiplies multipliers ('hundred', 'thousand', 'lakh', 'million', 'crore', etc.),
 * and accumulates exact sums.
 *
 * Example Test Cases:
 * - "twelve thousand two hundred fifty" -> 12250
 * - "ten thousand two hundred twenty" -> 10220
 * - "one lakh fifty-two thousand" -> 152000
 * - "fifty-five" -> 55
 * - "two million five hundred thousand" -> 2500000
 */
export function parseEnglishNumberText(spokenText: string): number {
  if (!spokenText || !spokenText.trim()) return 0;

  // Check direct comma-formatted sequences like 12,250 or 10,220
  const commaMatches = spokenText.match(/\b\d{1,3}(?:,\d{2,3})+(?:\.\d+)?\b/);
  if (commaMatches) {
    const directVal = parseFloat(commaMatches[0].replace(/,/g, ''));
    if (!isNaN(directVal) && directVal > 0) return Math.round(directVal);
  }

  // Clean punctuation, expand hyphens (e.g. 'twenty-five' -> 'twenty five')
  const clean = spokenText
    .replace(/-/g, ' ')
    .replace(/[,.?!:;'"()[\]{}]/g, ' ')
    .replace(/\band\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const words = clean.split(' ');
  let total = 0;
  let currentGroup = 0;
  let hasMatched = false;

  for (const word of words) {
    if (!word) continue;
    const lower = word.toLowerCase();

    // Check if word is already raw numeric digits (e.g. "12000" or "50")
    if (/^\d+(?:\.\d+)?$/.test(word)) {
      currentGroup += parseFloat(word);
      hasMatched = true;
      continue;
    }

    if (englishNumberDict[lower] !== undefined) {
      hasMatched = true;
      const value = englishNumberDict[lower];

      // Multipliers: 'hundred' multiplies the current group
      if (value === 100) {
        currentGroup = (currentGroup === 0 ? 1 : currentGroup) * 100;
      } else if (value >= 1000) {
        // Multipliers: 1000 and above (thousand, lakh, million, crore, billion)
        currentGroup = (currentGroup === 0 ? 1 : currentGroup) * value;
        total += currentGroup;
        currentGroup = 0;
      } else {
        // Units / Tens
        currentGroup += value;
      }
    }
  }

  total += currentGroup;
  return hasMatched ? Math.round(total) : 0;
}
