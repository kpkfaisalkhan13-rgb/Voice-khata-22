/**
 * Connectivity Service for Voice Udhaar / Khata Application
 * 
 * Implements:
 * 1. Real-time network connectivity detection (Wi-Fi, Mobile Data, Offline).
 * 2. Online API & Voice Recognition Guardrails.
 * 3. Offline Mode Simulation for testing environments.
 * 4. User-friendly notification messages in English & Urdu.
 */

export const VOICE_OFFLINE_NOTICE_EN =
  'Voice features require an internet connection. Please connect to the internet or use manual entry.';
export const VOICE_OFFLINE_NOTICE_UR =
  'آواز کی سہولت کے لیے انٹرنیٹ درکار ہے۔ برائے مہربانی انٹرنیٹ سے جڑیں یا دستی اندراج استعمال کریں۔';

export const CLOUD_OFFLINE_NOTICE_EN =
  'Cloud sync requires an internet connection. Please connect to Wi-Fi or mobile data.';
export const CLOUD_OFFLINE_NOTICE_UR =
  'کلاؤڈ سنک کے لیے انٹرنیٹ کنکشن درکار ہے۔ برائے مہربانی وائی فائی یا موبائل ڈیٹا سے جڑیں۔';

export type ConnectivityStatus = 'online' | 'offline';

type ConnectivityListener = (isOnline: boolean, simulated: boolean) => void;

class ConnectivityService {
  private isBrowserOnline: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private isSimulatedOffline: boolean = false;
  private listeners: Set<ConnectivityListener> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      // Check stored simulation preference if any
      const stored = localStorage.getItem('khata_simulate_offline');
      if (stored === 'true') {
        this.isSimulatedOffline = true;
      }

      window.addEventListener('online', () => {
        this.isBrowserOnline = true;
        this.notify();
      });

      window.addEventListener('offline', () => {
        this.isBrowserOnline = false;
        this.notify();
      });
    }
  }

  /**
   * Returns true if device has an active internet connection and not in simulated offline mode
   */
  public isConnected(): boolean {
    if (this.isSimulatedOffline) return false;
    return this.isBrowserOnline;
  }

  /**
   * Check if simulated offline mode is turned on
   */
  public isSimulatingOffline(): boolean {
    return this.isSimulatedOffline;
  }

  /**
   * Toggle offline simulation for testing offline/online transitions
   */
  public toggleSimulateOffline(): boolean {
    this.isSimulatedOffline = !this.isSimulatedOffline;
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('khata_simulate_offline', String(this.isSimulatedOffline));
    }
    this.notify();
    return this.isConnected();
  }

  public setSimulateOffline(offline: boolean): void {
    this.isSimulatedOffline = offline;
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('khata_simulate_offline', String(this.isSimulatedOffline));
    }
    this.notify();
  }

  /**
   * Guardrail check for Voice features
   * Returns true if online, or false if offline and invokes callback with clean notice
   */
  public checkVoiceAvailability(isUrdu: boolean = false): {
    allowed: boolean;
    message?: string;
  } {
    if (!this.isConnected()) {
      return {
        allowed: false,
        message: isUrdu ? VOICE_OFFLINE_NOTICE_UR : VOICE_OFFLINE_NOTICE_EN,
      };
    }
    return { allowed: true };
  }

  /**
   * Guardrail check for Cloud Sync features
   */
  public checkCloudAvailability(isUrdu: boolean = false): {
    allowed: boolean;
    message?: string;
  } {
    if (!this.isConnected()) {
      return {
        allowed: false,
        message: isUrdu ? CLOUD_OFFLINE_NOTICE_UR : CLOUD_OFFLINE_NOTICE_EN,
      };
    }
    return { allowed: true };
  }

  public subscribe(listener: ConnectivityListener): () => void {
    this.listeners.add(listener);
    listener(this.isConnected(), this.isSimulatedOffline);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const connected = this.isConnected();
    this.listeners.forEach((listener) => {
      try {
        listener(connected, this.isSimulatedOffline);
      } catch (err) {
        console.error('Error in connectivity listener', err);
      }
    });
  }
}

export const connectivityService = new ConnectivityService();
