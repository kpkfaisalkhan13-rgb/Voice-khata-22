// Voice-to-Text Speech Recognition Service (Groq Whisper, Groq AI Parser & Web Speech API)
import { VoiceEngineResponse } from '../types';

export interface TranscriptionResponse {
  text: string;
  source: 'groq_whisper' | 'web_speech' | 'simulation';
  error?: string;
}

export interface GroqParsedTransaction {
  account_name: string;
  amount: number;
  type: 'CREDIT' | 'DEBIT';
  raw_text: string;
}

export interface ExtractedTransaction {
  account_name: string;
  amount: number;
  type: 'CREDIT' | 'DEBIT';
}

export interface MultiTransactionParseResponse {
  transactions: ExtractedTransaction[];
}

export type VoiceIntent = 'ADD_TRANSACTION' | 'SEARCH_ACCOUNT';

export interface VoiceIntentClassification {
  intent: VoiceIntent;
  target_name: string;
  raw_text: string;
}

export async function transcribeAudioWithGroq(
  audioBlob: Blob,
  apiKey: string,
  model = 'whisper-large-v3-turbo'
): Promise<TranscriptionResponse> {
  if (!apiKey) {
    throw new Error('Groq API Key is missing.');
  }

  // Determine file extension from blob type
  let ext = 'webm';
  if (audioBlob.type.includes('mp4') || audioBlob.type.includes('m4a')) {
    ext = 'mp4';
  } else if (audioBlob.type.includes('ogg')) {
    ext = 'ogg';
  } else if (audioBlob.type.includes('wav')) {
    ext = 'wav';
  }

  const formData = new FormData();
  formData.append('file', audioBlob, `voice_recording.${ext}`);
  formData.append('model', model);
  formData.append(
    'prompt',
    'Voice Udhaar Khata ledger: Ali, Ahmed, Hamza, Tariq, Usman, Rahul, Khan. 500 diye, 1200 received, 300 wapas kiye, 10000 ادھار دیا، قرض، وصول، نقد روپے'
  );

  const response = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
    },
    body: formData,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const message = errorData.error?.message || `Groq Whisper API Error (${response.status})`;
    throw new Error(message);
  }

  const data = await response.json();
  return {
    text: (data.text || '').trim(),
    source: 'groq_whisper',
  };
}

/**
 * Transaction parser for "Voice Udhaar".
 * Parses continuous or multi-item voice input into a list of structured ledger entries.
 * Rules:
 * 1. Break down multiple statements into separate transaction objects.
 * 2. Calculate arithmetic operations within individual phrases if present.
 * 3. Identify person/category names, final amounts, and types (CREDIT or DEBIT).
 * Output Format (Strictly JSON):
 * {
 *   "transactions": [
 *     {
 *       "account_name": "<Extracted Name or Category>",
 *       "amount": <Calculated Number>,
 *       "type": "<CREDIT or DEBIT>"
 *     }
 *   ]
 * }
 */
export async function parseMultiTransactionsWithGroqAI(
  transcript: string,
  apiKey: string,
  model = 'llama-3.3-70b-versatile'
): Promise<MultiTransactionParseResponse | null> {
  if (!apiKey || !transcript.trim()) return null;

  const systemPrompt = `You are a transaction parser for "Voice Udhaar". Parse continuous or multi-item voice input into a list of structured ledger entries.

Rules:
1. Break down multiple statements into separate transaction objects.
2. Calculate arithmetic operations within individual phrases if present (e.g., "500 plus 200" = 700, "1000 aur 500" = 1500, "2000 minus 500" = 1500).
3. Identify person/category names, final amounts, and types (CREDIT or DEBIT):
   - "Give / Diye / Bheje / Udhaar / Qarz / Nikalwaye": DEBIT (Money given to customer or taken as debt)
   - "Got / Milay / Liya / Aaye / Wasool / Wapas / Received / Jama": CREDIT (Money received from customer or deposited)

Output Format (Strictly JSON):
{
  "transactions": [
    {
      "account_name": "<Extracted Name or Category>",
      "amount": <Calculated Number>,
      "type": "<CREDIT or DEBIT>"
    }
  ]
}`;

  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: transcript },
        ],
        temperature: 0.1,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      console.warn('Groq Chat multi-parser returned non-200:', response.status);
      return null;
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    if (!content) return null;

    const parsed = JSON.parse(content);
    const rawList = Array.isArray(parsed?.transactions)
      ? parsed.transactions
      : Array.isArray(parsed)
      ? parsed
      : [parsed];

    const validList: ExtractedTransaction[] = rawList
      .filter((item: any) => item && (item.account_name || item.name))
      .map((item: any) => ({
        account_name: String(item.account_name || item.name || '').trim(),
        amount:
          typeof item.amount === 'number'
            ? item.amount
            : parseFloat(String(item.amount).replace(/[^0-9.]/g, '')) || 0,
        type: String(item.type).toUpperCase() === 'CREDIT' ? 'CREDIT' : 'DEBIT',
      }))
      .filter((item: ExtractedTransaction) => item.account_name.length > 0);

    return {
      transactions: validList,
    };
  } catch (err) {
    console.warn('Groq AI multi-transaction parsing error:', err);
    return null;
  }
}

/**
 * Intent classifier for "Voice Udhaar" search queries.
 * Task:
 * Determine if the user wants to ADD a transaction or SEARCH/QUERY an existing account.
 * Output Format (Strictly JSON):
 * {
 *   "intent": "<ADD_TRANSACTION or SEARCH_ACCOUNT>",
 *   "target_name": "<Extracted Name>",
 *   "raw_text": "<Original Text>"
 * }
 */
export async function classifyVoiceIntentWithGroqAI(
  transcript: string,
  apiKey: string,
  model = 'llama-3.3-70b-versatile'
): Promise<VoiceIntentClassification | null> {
  if (!apiKey || !transcript.trim()) return null;

  const systemPrompt = `You are an intent classifier for "Voice Udhaar" search queries.

Task:
Determine if the user wants to ADD a transaction or SEARCH/QUERY an existing account.

Classification criteria:
1. SEARCH_ACCOUNT:
   The user wants to search, view, check balance, open ledger, or query an existing customer/account.
   Examples:
   - "Ali ka khata dikhao" -> SEARCH_ACCOUNT, target_name: "Ali"
   - "Show balance for Rahul" -> SEARCH_ACCOUNT, target_name: "Rahul"
   - "Search Usman" -> SEARCH_ACCOUNT, target_name: "Usman"
   - "Tariq ka hisab kya hai" -> SEARCH_ACCOUNT, target_name: "Tariq"
   - "علی کا کھاتہ دکھاؤ" -> SEARCH_ACCOUNT, target_name: "علی"
   - "عثمان کے کتنے پیسے بنتے ہیں" -> SEARCH_ACCOUNT, target_name: "عثمان"

2. ADD_TRANSACTION:
   The user wants to record or add a debit/credit transaction with an amount and person.
   Examples:
   - "Ali ko 500 diye" -> ADD_TRANSACTION, target_name: "Ali"
   - "Received 1200 from Rahul" -> ADD_TRANSACTION, target_name: "Rahul"
   - "Usman ne 300 wapas kiye" -> ADD_TRANSACTION, target_name: "Usman"
   - "علی کے کھاتے میں 10,000 لکھ دو" -> ADD_TRANSACTION, target_name: "علی"
   - "500 plus 200 Ali ko diye" -> ADD_TRANSACTION, target_name: "Ali"

Output Format (Strictly JSON):
{
  "intent": "<ADD_TRANSACTION or SEARCH_ACCOUNT>",
  "target_name": "<Extracted Name>",
  "raw_text": "<Original Text>"
}`;

  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: transcript },
        ],
        temperature: 0.1,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      console.warn('Groq Chat intent classifier returned non-200:', response.status);
      return null;
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    if (!content) return null;

    const parsed = JSON.parse(content);
    const intent: VoiceIntent =
      String(parsed.intent).toUpperCase() === 'SEARCH_ACCOUNT'
        ? 'SEARCH_ACCOUNT'
        : 'ADD_TRANSACTION';

    return {
      intent,
      target_name: String(parsed.target_name || '').trim(),
      raw_text: transcript,
    };
  } catch (err) {
    console.warn('Groq AI intent classification error:', err);
    return null;
  }
}

/**
 * Advanced Multilingual Voice Engine (Groq AI)
 * Handles Voice Calculations and Ledger Transactions, recognizing existing accounts to prevent duplicates
 */
export async function processWithVoiceEngineGroqAI(
  transcript: string,
  existingAccounts: { id: string; name: string; nameUrdu: string }[],
  apiKey: string,
  model = 'llama-3.3-70b-versatile'
): Promise<VoiceEngineResponse | null> {
  if (!apiKey || !transcript.trim()) return null;

  const existingAccountsListText =
    existingAccounts.length > 0
      ? existingAccounts.map((a) => `- "${a.name}" / "${a.nameUrdu}"`).join('\n')
      : 'None';

  const systemPrompt = `You are an advanced multilingual Voice Engine for the "Voice Ledger" application, handling both Voice Calculations and Ledger Transactions.

Your primary duties are:
1. Parse mathematical speech input into exact expressions and calculated results.
2. Parse ledger transaction speech input, recognizing existing account names to prevent duplicate account creation.

=========================================
1. LEDGER & EXISTING ACCOUNT MERGING LOGIC
=========================================
- ENTITY MATCHING & MERGING:
  * Extract the person/business name spoken in the input.
  * Compare the extracted name against the provided existing account list:
${existingAccountsListText}
  * If the spoken name matches or is a close variation/fuzzy match of an existing account (e.g., "Ali", "Ali Khan", "علی"), set is_existing_account: true and map it strictly to that target account.
  * DO NOT create a new account entry if a matching account already exists in the system; append the transaction to the existing account.
  * If no matching account exists, set is_existing_account: false.

- TRANSACTION TYPE MAPPING:
  * Debit / Cash Out / Lent ("diye", "دیے", "دئے", "قرض دیا", "bheje", "debit") -> DEBIT
  * Credit / Cash In / Received ("liya", "لیے", "وصول کیے", "aaye", "milay", "credit") -> CREDIT

=========================================
2. NUMBER CONSTRUCTION & MATH LOGIC
=========================================
- POSITIONAL & CUMULATIVE VALUE ALGORITHM:
  * Continuously track positional base values (e.g., units, tens, hundreds, thousands, hundred-thousands/lakhs, millions).
  * Additive & Multiplicative Stacking:
    - When a multiplier word ("hundred", "thousand", "lakh", "million", "ہزار", "لاکھ") follows a digit, multiply that digit by the base unit.
    - Sequentially aggregate non-overlapping positional values into a single consolidated integer.
    - Handle long continuous number phrases without splitting them into separate digits.

- OPERATOR MAPPING:
  * Addition ("plus", "add", "jama", "جمع", "+") -> (+)
  * Subtraction ("minus", "subtract", "manfi", "منفی", "-") -> (-)
  * Multiplication ("multiply", "times", "zarb", "ضرب", "*") -> (*)
  * Division ("divided by", "divide", "taqseem", "تقسیم", "/") -> (/)

=========================================
3. NOISE & CONTEXT FILTERING
=========================================
- Ignore filler words, natural speech pauses, hesitation sounds, and conversational connectors ("اور", "پھر", "then", "and", "uhm").
- Maintain the chronological order of operations or transaction sequences as spoken by the user.

=========================================
4. EXPLICIT JSON OUTPUT STRUCTURE
=========================================
Strictly output the response in the following JSON format without any extra text or conversational explanations:

{
  "mode": "<LEDGER or CALCULATOR>",
  "ledger_data": {
    "account_name": "<Extracted or Matched Account Name>",
    "is_existing_account": <true or false>,
    "amount": <Final Calculated Transaction Amount>,
    "type": "<CREDIT or DEBIT>"
  },
  "calculator_data": {
    "expression": "<Standard formatted mathematical string using numbers and operators>",
    "result": <Evaluated numeric value (integer or float)>
  },
  "raw_text": "<Original transcribed user input>"
}

Important Rules:
- If speech is purely a calculation without a person/account or transaction verb (e.g. "500 plus 200", "10 hazar zarb 3", "1500 تقسیم 3"), set mode to "CALCULATOR", ledger_data to null, and populate calculator_data.
- If speech describes a transaction for an account/person, set mode to "LEDGER". Populate ledger_data (amount must be final evaluated number). If arithmetic was in the phrase (e.g. "500 plus 200"), populate calculator_data as well.`;

  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: transcript },
        ],
        temperature: 0.1,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      console.warn('Groq Voice Engine returned non-200:', response.status);
      return null;
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    if (!content) return null;

    const parsed = JSON.parse(content);
    return {
      mode: parsed.mode === 'CALCULATOR' ? 'CALCULATOR' : 'LEDGER',
      ledger_data: parsed.ledger_data
        ? {
            account_name: String(parsed.ledger_data.account_name || '').trim(),
            is_existing_account: Boolean(parsed.ledger_data.is_existing_account),
            amount: Number(parsed.ledger_data.amount || 0),
            type:
              String(parsed.ledger_data.type).toUpperCase() === 'CREDIT'
                ? 'CREDIT'
                : 'DEBIT',
          }
        : null,
      calculator_data: parsed.calculator_data
        ? {
            expression: String(parsed.calculator_data.expression || ''),
            result: Number(parsed.calculator_data.result || 0),
          }
        : null,
      raw_text: transcript,
    };
  } catch (err) {
    console.warn('Groq Voice Engine error:', err);
    return null;
  }
}

/**
 * Groq AI Dual-Language NLP Transaction Parser (Single transaction wrapper)
 */
export async function parseTransactionWithGroqAI(
  transcript: string,
  apiKey: string,
  model = 'llama-3.3-70b-versatile'
): Promise<GroqParsedTransaction | null> {
  const multiRes = await parseMultiTransactionsWithGroqAI(transcript, apiKey, model);
  if (multiRes && multiRes.transactions.length > 0) {
    const first = multiRes.transactions[0];
    return {
      account_name: first.account_name,
      amount: first.amount,
      type: first.type,
      raw_text: transcript,
    };
  }
  return null;
}

// Browser Web Speech API helper for zero-config live Urdu voice recognition
export class BrowserUrduSpeechRecognizer {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private recognition: any = null;
  private isListening = false;
  private onResultCallback: ((text: string, isFinal: boolean) => void) | null = null;
  private onErrorCallback: ((error: string) => void) | null = null;
  private onEndCallback: (() => void) | null = null;

  constructor() {
    const SpeechRecognitionClass =
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognitionClass) {
      this.recognition = new SpeechRecognitionClass();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'ur-PK'; // Urdu (Pakistan)
      this.recognition.maxAlternatives = 1;

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const currentText = finalTranscript || interimTranscript;
        if (this.onResultCallback && currentText) {
          this.onResultCallback(currentText, !!finalTranscript);
        }
      };

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.recognition.onerror = (event: any) => {
        console.warn('Web Speech error:', event.error);
        if (this.onErrorCallback) {
          this.onErrorCallback(event.error || 'Speech recognition error');
        }
      };

      this.recognition.onend = () => {
        this.isListening = false;
        if (this.onEndCallback) {
          this.onEndCallback();
        }
      };
    }
  }

  isSupported(): boolean {
    return !!this.recognition;
  }

  start(
    onResult: (text: string, isFinal: boolean) => void,
    onError: (error: string) => void,
    onEnd: () => void
  ) {
    if (!this.recognition) {
      onError('Browser Speech Recognition not supported on this browser.');
      return;
    }

    this.onResultCallback = onResult;
    this.onErrorCallback = onError;
    this.onEndCallback = onEnd;

    try {
      this.recognition.start();
      this.isListening = true;
    } catch (e) {
      console.warn('Recognition start exception:', e);
    }
  }

  stop() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch {
        // Ignore
      }
      this.isListening = false;
    }
  }
}
