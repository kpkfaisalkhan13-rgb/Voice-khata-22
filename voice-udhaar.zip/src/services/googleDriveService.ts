/**
 * Google Drive API (OAuth 2.0) User-Side Backup Service
 * 
 * Provides zero-server, user-side cloud backup directly into the user's personal Google Drive
 * using standard OAuth 2.0 with the restricted 'https://www.googleapis.com/auth/drive.file' scope.
 * 
 * The app only accesses files it creates (VoiceUdhaarApp_Backups folder).
 * Data uploaded is the AES-256 GCM encrypted SQLCipher database payload.
 */

export interface GoogleDriveFile {
  id: string;
  name: string;
  createdTime: string;
  size?: string;
}

const GDRIVE_TOKEN_KEY = 'voice_udhaar_gdrive_token';
const GDRIVE_EXPIRY_KEY = 'voice_udhaar_gdrive_token_expiry';
const GDRIVE_CLIENT_ID_KEY = 'voice_udhaar_gdrive_client_id';

class GoogleDriveService {
  private accessToken: string | null = null;
  private tokenExpiry: number = 0;
  private clientId: string = '';

  constructor() {
    this.accessToken = localStorage.getItem(GDRIVE_TOKEN_KEY);
    const exp = localStorage.getItem(GDRIVE_EXPIRY_KEY);
    this.tokenExpiry = exp ? parseInt(exp, 10) : 0;
    this.clientId =
      localStorage.getItem(GDRIVE_CLIENT_ID_KEY) ||
      '268805084914-kpvl79edl5gevsc74thnbid575h5j4j8.apps.googleusercontent.com';
  }

  public getClientId(): string {
    return this.clientId;
  }

  public setClientId(id: string): void {
    this.clientId = id.trim();
    localStorage.setItem(GDRIVE_CLIENT_ID_KEY, this.clientId);
  }

  public isConnected(): boolean {
    if (!this.accessToken) return false;
    // Check if token has not expired
    return Date.now() < this.tokenExpiry;
  }

  public setToken(token: string, expiresInSeconds: number = 3600): void {
    this.accessToken = token;
    this.tokenExpiry = Date.now() + expiresInSeconds * 1000;
    localStorage.setItem(GDRIVE_TOKEN_KEY, token);
    localStorage.setItem(GDRIVE_EXPIRY_KEY, this.tokenExpiry.toString());
  }

  public disconnect(): void {
    this.accessToken = null;
    this.tokenExpiry = 0;
    localStorage.removeItem(GDRIVE_TOKEN_KEY);
    localStorage.removeItem(GDRIVE_EXPIRY_KEY);
  }

  /**
   * Uploads the SQLCipher encrypted backup string directly to Google Drive as an encrypted file.
   */
  public async uploadEncryptedBackup(
    encryptedContent: string,
    fileName: string = `VoiceUdhaar_Backup_${new Date().toISOString().slice(0, 10)}.db.enc`
  ): Promise<{ success: boolean; fileId?: string; error?: string }> {
    if (!this.isConnected() || !this.accessToken) {
      return { success: false, error: 'Google Drive متصل نہیں ہے (Not connected).' };
    }

    try {
      const metadata = {
        name: fileName,
        mimeType: 'application/octet-stream',
        description: 'Voice Udhaar SQLCipher AES-256 Encrypted Offline Backup',
      };

      const boundary = '-------314159265358979323846';
      const delimiter = `\r\n--${boundary}\r\n`;
      const closeDelim = `\r\n--${boundary}--`;

      const multipartRequestBody =
        delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        'Content-Type: application/octet-stream\r\n\r\n' +
        encryptedContent +
        closeDelim;

      const response = await fetch(
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'Content-Type': `multipart/related; boundary=${boundary}`,
          },
          body: multipartRequestBody,
        }
      );

      if (!response.ok) {
        const errText = await response.text();
        return { success: false, error: `Drive Error: ${response.status} - ${errText}` };
      }

      const result = await response.json();
      return { success: true, fileId: result.id };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return { success: false, error: msg };
    }
  }

  /**
   * Lists backup files created by this app on Google Drive
   */
  public async listBackups(): Promise<GoogleDriveFile[]> {
    if (!this.isConnected() || !this.accessToken) {
      return [];
    }

    try {
      const query = encodeURIComponent(
        "name contains 'VoiceUdhaar_Backup' and trashed = false"
      );
      const url = `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,createdTime,size)&orderBy=createdTime desc`;

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      });

      if (!response.ok) return [];
      const data = await response.json();
      return data.files || [];
    } catch {
      return [];
    }
  }

  /**
   * Downloads the content of a specific backup file from Google Drive
   */
  public async downloadBackupContent(fileId: string): Promise<string | null> {
    if (!this.isConnected() || !this.accessToken) return null;

    try {
      const response = await fetch(
        `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
          },
        }
      );

      if (!response.ok) return null;
      return await response.text();
    } catch {
      return null;
    }
  }
}

export const googleDriveService = new GoogleDriveService();
