import initSqlJs, { Database } from 'sql.js';
import { Customer, Transaction, AppSettings, SubscriptionInfo, UserVoiceCorrection, SelfLearningItem } from '../types';
import { encryptData, decryptText, EncryptedPayload } from '../utils/crypto';
import { DEFAULT_SUBSCRIPTION } from '../utils/subscription';

const SQLITE_STORAGE_KEY = 'voice_udhaar_sqlcipher_enc_v1';
const SETTINGS_STORAGE_KEY = 'voice_udhaar_settings_v1';
export const VOICE_CORRECTIONS_STORAGE_KEY = 'user_voice_corrections_v1';
export const SELF_LEARNING_STORAGE_KEY = 'smart_paste_learning_dictionary_v1';

const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    name: 'Ali',
    nameUrdu: 'علی',
    phone: '0300-1234567',
    address: 'دکان نمبر ۴، مین بازار',
    balance: 14000,
    debtLimit: 20000,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: 'cust-2',
    name: 'Ahmed',
    nameUrdu: 'احمد',
    phone: '0301-7654321',
    address: 'گلی نمبر ۲، محلہ عثمانیہ',
    balance: 2500,
    debtLimit: 15000,
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: 'cust-3',
    name: 'Hamza',
    nameUrdu: 'حمزہ',
    phone: '0333-9876543',
    address: 'نزد جامع مسجد',
    balance: 0,
    debtLimit: 25000,
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 'cust-4',
    name: 'Tariq',
    nameUrdu: 'طارق',
    phone: '0321-4567890',
    address: 'سبزی منڈی روڈ',
    balance: 18500,
    debtLimit: 15000, // Balance (18500) > debtLimit (15000) -> Triggers alert!
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'cust-5',
    name: 'Usman',
    nameUrdu: 'عثمان',
    phone: '0345-1122334',
    address: 'چوک یادگار',
    balance: 8000,
    debtLimit: 25000,
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 4).toISOString(),
  },
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1',
    customerId: 'cust-1',
    customerName: 'Ali',
    customerNameUrdu: 'علی',
    amount: 14000,
    type: 'DEBIT',
    note: 'پرانا بقایا ادھار سامان',
    timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 'tx-2',
    customerId: 'cust-2',
    customerName: 'Ahmed',
    customerNameUrdu: 'احمد',
    amount: 2500,
    type: 'DEBIT',
    note: 'راشن کریانہ ادھار',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'tx-3',
    customerId: 'cust-4',
    customerName: 'Tariq',
    customerNameUrdu: 'طارق',
    amount: 18500,
    type: 'DEBIT',
    note: 'بلک کریانہ سپلائی ادھار',
    timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: 'tx-4',
    customerId: 'cust-5',
    customerName: 'Usman',
    customerNameUrdu: 'عثمان',
    amount: 8000,
    type: 'DEBIT',
    note: 'گھی اور چینی ادھار',
    timestamp: new Date(Date.now() - 86400000 * 4).toISOString(),
  },
  {
    id: 'tx-5',
    customerId: 'cust-1',
    customerName: 'Ali',
    customerNameUrdu: 'علی',
    amount: 4000,
    type: 'CREDIT',
    note: 'نقد وصولی بذریعہ ایزی پیسہ',
    timestamp: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
];

export const DEFAULT_SETTINGS: AppSettings = {
  pin: '',
  biometricEnabled: false,
  isLocked: false,
  language: 'ur',
  country: 'PK',
  businessName: 'My Ledger / میرا کھاتہ',
  onboardingCompleted: false,
  groqApiKey: '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',
  whisperModel: 'whisper-large-v3-turbo',
  shopName: 'My Ledger / میرا کھاتہ',
  shopOwner: 'محمد عامر',
  currency: 'روپے (PKR)',
  lastBackupTime: null,
  subscription: DEFAULT_SUBSCRIPTION,
  defaultDebtLimit: 20000,
  enableDebtAlerts: true,
};

class LocalDatabase {
  private db: Database | null = null;
  private isInitialized = false;
  private customersCache: Customer[] = [];
  private transactionsCache: Transaction[] = [];
  private voiceCorrectionsCache: UserVoiceCorrection[] = [];
  private settingsCache: AppSettings = { ...DEFAULT_SETTINGS };

  async init(): Promise<void> {
    if (this.isInitialized) return;

    // Load settings from storage
    this.loadSettings();

    // Load voice corrections from local storage
    try {
      const storedVC = localStorage.getItem(VOICE_CORRECTIONS_STORAGE_KEY);
      if (storedVC) {
        this.voiceCorrectionsCache = JSON.parse(storedVC);
      }
    } catch {
      this.voiceCorrectionsCache = [];
    }

    // Check if we have an encrypted SQLCipher payload stored
    const storedEncrypted = localStorage.getItem(SQLITE_STORAGE_KEY);
    if (storedEncrypted) {
      try {
        const payload: EncryptedPayload = JSON.parse(storedEncrypted);
        const decryptedJson = await decryptText(payload, this.settingsCache.pin || '1234');
        const data = JSON.parse(decryptedJson);
        this.customersCache = data.customers || INITIAL_CUSTOMERS;
        this.transactionsCache = data.transactions || INITIAL_TRANSACTIONS;
        if (data.voiceCorrections && Array.isArray(data.voiceCorrections)) {
          this.voiceCorrectionsCache = data.voiceCorrections;
        }
      } catch (decErr) {
        console.warn('Failed to decrypt stored payload, using fallback:', decErr);
        this.customersCache = INITIAL_CUSTOMERS;
        this.transactionsCache = INITIAL_TRANSACTIONS;
      }
    } else {
      this.customersCache = INITIAL_CUSTOMERS;
      this.transactionsCache = INITIAL_TRANSACTIONS;
    }

    try {
      // Safely load and verify the SQL.js WASM binary before passing to Emscripten
      // to avoid uncaught browser abort exceptions if the server returns HTML fallback
      let wasmBinary: ArrayBuffer | null = null;
      const candidates = [
        '/sql-wasm.wasm',
        'https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.14.2/sql-wasm.wasm'
      ];
      for (const url of candidates) {
        try {
          const res = await fetch(url);
          if (!res.ok) continue;
          const contentType = res.headers.get('content-type') || '';
          if (contentType.includes('html')) continue;
          const buffer = await res.arrayBuffer();
          const header = new Uint8Array(buffer.slice(0, 4));
          // Verify WebAssembly magic header: 0x00 0x61 0x73 0x6d ('\0asm')
          if (header[0] === 0x00 && header[1] === 0x61 && header[2] === 0x73 && header[3] === 0x6d) {
            wasmBinary = buffer;
            break;
          }
        } catch {
          // try next candidate
        }
      }

      if (wasmBinary) {
        const SQL = await initSqlJs({ wasmBinary });
        this.db = new SQL.Database();
        this.createTables();
        this.populateSQLiteFromCache();
      } else {
        console.info('Khata initialized using local encrypted WebCrypto storage engine.');
      }
      this.isInitialized = true;
    } catch (e) {
      console.warn('SQLite WASM initialization note: running on encrypted local state engine:', e);
      this.isInitialized = true;
    }
  }

  private createTables() {
    if (!this.db) return;
    this.db.run(`
      CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        nameUrdu TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        balance REAL DEFAULT 0,
        debtLimit REAL DEFAULT 20000,
        createdAt TEXT,
        updatedAt TEXT
      );

      CREATE TABLE IF NOT EXISTS transactions (
        id TEXT PRIMARY KEY,
        customerId TEXT NOT NULL,
        customerName TEXT NOT NULL,
        customerNameUrdu TEXT NOT NULL,
        amount REAL NOT NULL,
        type TEXT NOT NULL,
        note TEXT,
        rawTranscript TEXT,
        timestamp TEXT,
        FOREIGN KEY (customerId) REFERENCES customers(id)
      );

      CREATE TABLE IF NOT EXISTS user_voice_corrections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        spoken_transcript TEXT NOT NULL,
        corrected_number REAL NOT NULL,
        updated_at TEXT NOT NULL
      );
    `);
  }

  private populateSQLiteFromCache() {
    if (!this.db) return;
    this.db.run('DELETE FROM customers');
    this.db.run('DELETE FROM transactions');
    this.db.run('DELETE FROM user_voice_corrections');

    const insertCustStmt = this.db.prepare(`
      INSERT INTO customers (id, name, nameUrdu, phone, address, balance, debtLimit, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const c of this.customersCache) {
      insertCustStmt.run([
        c.id,
        c.name,
        c.nameUrdu,
        c.phone,
        c.address || '',
        c.balance,
        c.debtLimit ?? 20000,
        c.createdAt,
        c.updatedAt,
      ]);
    }
    insertCustStmt.free();

    const insertTxStmt = this.db.prepare(`
      INSERT INTO transactions (id, customerId, customerName, customerNameUrdu, amount, type, note, rawTranscript, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const t of this.transactionsCache) {
      insertTxStmt.run([t.id, t.customerId, t.customerName, t.customerNameUrdu, t.amount, t.type, t.note, t.rawTranscript || '', t.timestamp]);
    }
    insertTxStmt.free();

    const insertVcStmt = this.db.prepare(`
      INSERT INTO user_voice_corrections (spoken_transcript, corrected_number, updated_at)
      VALUES (?, ?, ?)
    `);
    for (const vc of this.voiceCorrectionsCache) {
      insertVcStmt.run([vc.spoken_transcript, vc.corrected_number, vc.updated_at]);
    }
    insertVcStmt.free();
  }

  private async persistEncrypted() {
    try {
      const dataToSave = {
        customers: this.customersCache,
        transactions: this.transactionsCache,
        voiceCorrections: this.voiceCorrectionsCache,
        timestamp: new Date().toISOString(),
      };
      const json = JSON.stringify(dataToSave);
      const encrypted = await encryptData(json, this.settingsCache.pin || '1234');
      localStorage.setItem(SQLITE_STORAGE_KEY, JSON.stringify(encrypted));
      localStorage.setItem(VOICE_CORRECTIONS_STORAGE_KEY, JSON.stringify(this.voiceCorrectionsCache));
    } catch (e) {
      console.error('Failed to persist encrypted SQLCipher state:', e);
    }
  }

  // Customers
  getCustomers(): Customer[] {
    return [...this.customersCache];
  }

  getCustomerById(id: string): Customer | undefined {
    return this.customersCache.find((c) => c.id === id);
  }

  async addCustomer(customerData: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>): Promise<Customer> {
    const newCustomer: Customer = {
      ...customerData,
      debtLimit: customerData.debtLimit ?? this.settingsCache.defaultDebtLimit ?? 20000,
      id: `cust-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.customersCache = [newCustomer, ...this.customersCache];

    if (this.db) {
      const stmt = this.db.prepare(`
        INSERT INTO customers (id, name, nameUrdu, phone, address, balance, debtLimit, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run([
        newCustomer.id,
        newCustomer.name,
        newCustomer.nameUrdu,
        newCustomer.phone,
        newCustomer.address || '',
        newCustomer.balance,
        newCustomer.debtLimit ?? 20000,
        newCustomer.createdAt,
        newCustomer.updatedAt,
      ]);
      stmt.free();
    }

    await this.persistEncrypted();
    return newCustomer;
  }

  async updateCustomer(id: string, updates: Partial<Customer>): Promise<Customer | null> {
    const index = this.customersCache.findIndex((c) => c.id === id);
    if (index === -1) return null;

    const updated = {
      ...this.customersCache[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    this.customersCache[index] = updated;

    if (this.db) {
      const stmt = this.db.prepare(`
        UPDATE customers SET name = ?, nameUrdu = ?, phone = ?, address = ?, balance = ?, debtLimit = ?, updatedAt = ?
        WHERE id = ?
      `);
      stmt.run([
        updated.name,
        updated.nameUrdu,
        updated.phone,
        updated.address || '',
        updated.balance,
        updated.debtLimit ?? 20000,
        updated.updatedAt,
        id,
      ]);
      stmt.free();
    }

    await this.persistEncrypted();
    return updated;
  }

  async deleteCustomer(id: string): Promise<boolean> {
    const cust = this.customersCache.find((c) => c.id === id);
    this.customersCache = this.customersCache.filter((c) => c.id !== id);
    this.transactionsCache = this.transactionsCache.filter((t) => t.customerId !== id);

    if (this.db) {
      try {
        const stmt1 = this.db.prepare(`DELETE FROM customers WHERE id = ?`);
        stmt1.run([id]);
        stmt1.free();
        const stmt2 = this.db.prepare(`DELETE FROM transactions WHERE id = ?`);
        stmt2.run([id]);
        stmt2.free();
      } catch (e) {
        console.warn('SQLite delete error:', e);
      }
    }

    await this.persistEncrypted();
    return true;
  }

  // Transactions
  getTransactions(customerId?: string): Transaction[] {
    if (customerId) {
      return this.transactionsCache.filter((t) => t.customerId === customerId);
    }
    return [...this.transactionsCache];
  }

  async addTransaction(txData: Omit<Transaction, 'id' | 'timestamp'>): Promise<{ transaction: Transaction; customer: Customer }> {
    const customer = this.customersCache.find((c) => c.id === txData.customerId);
    if (!customer) {
      throw new Error(`Customer with ID ${txData.customerId} not found`);
    }

    const newTx: Transaction = {
      ...txData,
      id: `tx-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString(),
    };

    // Calculate new balance:
    // DEBIT (قرض دیا): customer owes merchant more (+ amount)
    // CREDIT (وصولی / نقد ملے): customer paid, owes less (- amount)
    const delta = txData.type === 'DEBIT' ? txData.amount : -txData.amount;
    const newBalance = customer.balance + delta;

    this.transactionsCache = [newTx, ...this.transactionsCache];
    const updatedCustomer = {
      ...customer,
      balance: newBalance,
      updatedAt: new Date().toISOString(),
    };

    const cIdx = this.customersCache.findIndex((c) => c.id === customer.id);
    if (cIdx !== -1) {
      this.customersCache[cIdx] = updatedCustomer;
    }

    if (this.db) {
      const txStmt = this.db.prepare(`
        INSERT INTO transactions (id, customerId, customerName, customerNameUrdu, amount, type, note, rawTranscript, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      txStmt.run([
        newTx.id,
        newTx.customerId,
        newTx.customerName,
        newTx.customerNameUrdu,
        newTx.amount,
        newTx.type,
        newTx.note,
        newTx.rawTranscript || '',
        newTx.timestamp,
      ]);
      txStmt.free();

      const custStmt = this.db.prepare(`UPDATE customers SET balance = ?, updatedAt = ? WHERE id = ?`);
      custStmt.run([newBalance, updatedCustomer.updatedAt, customer.id]);
      custStmt.free();
    }

    await this.persistEncrypted();
    return { transaction: newTx, customer: updatedCustomer };
  }

  // Settings
  getSettings(): AppSettings {
    return { ...this.settingsCache };
  }

  saveSettings(updates: Partial<AppSettings>): AppSettings {
    this.settingsCache = { ...this.settingsCache, ...updates };
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(this.settingsCache));
    return { ...this.settingsCache };
  }

  private loadSettings() {
    try {
      const stored = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        this.settingsCache = {
          ...DEFAULT_SETTINGS,
          ...parsed,
          subscription: {
            ...DEFAULT_SUBSCRIPTION,
            ...(parsed.subscription || {}),
          },
        };
        if (!this.settingsCache.groqApiKey) {
          this.settingsCache.groqApiKey = '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';
          this.saveSettings({ groqApiKey: this.settingsCache.groqApiKey });
        }
      }
    } catch {
      this.settingsCache = { ...DEFAULT_SETTINGS };
    }
  }

  updateSubscription(updates: Partial<SubscriptionInfo>): SubscriptionInfo {
    const currentSub = this.settingsCache.subscription || DEFAULT_SUBSCRIPTION;
    const newSub: SubscriptionInfo = { ...currentSub, ...updates };
    this.saveSettings({ subscription: newSub });
    return newSub;
  }

  extendSubscription(plan: 'VOICE' | 'PDF_ANALYTICS' | 'COMBO', days = 30): SubscriptionInfo {
    const currentSub = this.settingsCache.subscription || DEFAULT_SUBSCRIPTION;
    const now = Date.now();
    const addMs = days * 24 * 60 * 60 * 1000;

    let voiceExpiresAt = currentSub.voiceExpiresAt;
    let pdfAnalyticsExpiresAt = currentSub.pdfAnalyticsExpiresAt;

    if (plan === 'VOICE' || plan === 'COMBO') {
      const baseTime = voiceExpiresAt && new Date(voiceExpiresAt).getTime() > now
        ? new Date(voiceExpiresAt).getTime()
        : now;
      voiceExpiresAt = new Date(baseTime + addMs).toISOString();
    }

    if (plan === 'PDF_ANALYTICS' || plan === 'COMBO') {
      const baseTime = pdfAnalyticsExpiresAt && new Date(pdfAnalyticsExpiresAt).getTime() > now
        ? new Date(pdfAnalyticsExpiresAt).getTime()
        : now;
      pdfAnalyticsExpiresAt = new Date(baseTime + addMs).toISOString();
    }

    const updatedSub: SubscriptionInfo = {
      ...currentSub,
      voiceExpiresAt,
      pdfAnalyticsExpiresAt,
      adminExtendedDays: (currentSub.adminExtendedDays || 0) + days,
      paymentPendingPlan: undefined,
    };

    this.saveSettings({ subscription: updatedSub });
    return updatedSub;
  }

  simulateTrialDay(targetDay: number): SubscriptionInfo {
    // If targetDay = 5 -> installedAt = now - 4 days
    // If targetDay = 35 -> installedAt = now - 34 days
    const daysAgo = Math.max(0, targetDay - 1);
    const simulatedDate = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString();
    return this.updateSubscription({ installedAt: simulatedDate });
  }

  // Backup & SQLCipher Export
  async exportEncryptedBackup(): Promise<string> {
    const data = {
      version: 1,
      appName: 'Voice Udhaar',
      exportedAt: new Date().toISOString(),
      customers: this.customersCache,
      transactions: this.transactionsCache,
      voiceCorrections: this.voiceCorrectionsCache,
      settings: {
        shopName: this.settingsCache.shopName,
        shopOwner: this.settingsCache.shopOwner,
        language: this.settingsCache.language,
      },
    };
    const json = JSON.stringify(data, null, 2);
    const encrypted = await encryptData(json, this.settingsCache.pin || '1234');
    return JSON.stringify(encrypted);
  }

  async importEncryptedBackup(encryptedJsonString: string, pin: string): Promise<boolean> {
    try {
      const payload: EncryptedPayload = JSON.parse(encryptedJsonString);
      const decrypted = await decryptText(payload, pin);
      const data = JSON.parse(decrypted);

      if (data.customers && Array.isArray(data.customers)) {
        this.customersCache = data.customers;
        this.transactionsCache = data.transactions || [];
        if (data.voiceCorrections && Array.isArray(data.voiceCorrections)) {
          this.voiceCorrectionsCache = data.voiceCorrections;
        }
        this.populateSQLiteFromCache();
        await this.persistEncrypted();
        return true;
      }
      return false;
    } catch (e) {
      console.error('Failed to import backup:', e);
      throw e;
    }
  }

  // ============================================================================
  // USER VOICE CORRECTIONS (Local Custom Mapping & Dynamic Learning System)
  // ============================================================================
  getUserVoiceCorrections(): UserVoiceCorrection[] {
    return [...this.voiceCorrectionsCache];
  }

  async saveUserVoiceCorrection(
    spokenTranscript: string,
    correctedNumber: number
  ): Promise<UserVoiceCorrection> {
    const rawClean = (spokenTranscript || '').trim();
    if (!rawClean || isNaN(correctedNumber) || correctedNumber <= 0) {
      throw new Error('Invalid spoken transcript or corrected number');
    }

    const normKey = this.normalizeVoiceTranscript(rawClean);

    // Check if an existing correction matches this transcript
    const existingIndex = this.voiceCorrectionsCache.findIndex(
      (c) => this.normalizeVoiceTranscript(c.spoken_transcript) === normKey
    );

    const nowIso = new Date().toISOString();
    let record: UserVoiceCorrection;

    if (existingIndex >= 0) {
      record = {
        ...this.voiceCorrectionsCache[existingIndex],
        spoken_transcript: rawClean,
        corrected_number: correctedNumber,
        updated_at: nowIso,
      };
      this.voiceCorrectionsCache[existingIndex] = record;
    } else {
      record = {
        id: `uvc-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        spoken_transcript: rawClean,
        corrected_number: correctedNumber,
        updated_at: nowIso,
      };
      this.voiceCorrectionsCache = [record, ...this.voiceCorrectionsCache];
    }

    // Update SQLite table if available
    if (this.db) {
      try {
        const stmt = this.db.prepare(`
          INSERT OR REPLACE INTO user_voice_corrections (id, spoken_transcript, corrected_number, updated_at)
          VALUES (?, ?, ?, ?)
        `);
        stmt.run([record.id, record.spoken_transcript, record.corrected_number, record.updated_at]);
        stmt.free();
      } catch (err) {
        console.warn('SQLite user_voice_corrections update error:', err);
      }
    }

    // Persist immediately to localStorage and encrypted storage
    try {
      localStorage.setItem(VOICE_CORRECTIONS_STORAGE_KEY, JSON.stringify(this.voiceCorrectionsCache));
    } catch {
      // Ignore
    }
    await this.persistEncrypted();

    // Dispatch global event for reactive UI updates
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('voice_corrections_updated', { detail: record }));
    }

    return record;
  }

  findVoiceCorrection(spokenTranscript: string): UserVoiceCorrection | null {
    if (!spokenTranscript || !spokenTranscript.trim()) return null;

    let list = this.voiceCorrectionsCache;
    if (list.length === 0) {
      try {
        const stored = localStorage.getItem(VOICE_CORRECTIONS_STORAGE_KEY);
        if (stored) {
          list = JSON.parse(stored);
          this.voiceCorrectionsCache = list;
        }
      } catch {
        list = [];
      }
    }

    if (list.length === 0) return null;

    const raw = spokenTranscript.trim();
    const queryNorm = this.normalizeVoiceTranscript(raw);

    // 1. Exact match (case-insensitive & trimmed)
    const exact = list.find(
      (c) => c.spoken_transcript.trim().toLowerCase() === raw.toLowerCase()
    );
    if (exact) return exact;

    // 2. Normalized match (without tashkeel, punctuation, extra spaces)
    const normalizedMatch = list.find(
      (c) => this.normalizeVoiceTranscript(c.spoken_transcript) === queryNorm
    );
    if (normalizedMatch) return normalizedMatch;

    // 3. Substring / Token subset fuzzy match
    for (const item of list) {
      const itemNorm = this.normalizeVoiceTranscript(item.spoken_transcript);
      if (itemNorm.length >= 3 && (queryNorm.includes(itemNorm) || itemNorm.includes(queryNorm))) {
        return item;
      }
    }

    return null;
  }

  async deleteVoiceCorrection(id: string): Promise<boolean> {
    this.voiceCorrectionsCache = this.voiceCorrectionsCache.filter((c) => c.id !== id);
    if (this.db) {
      try {
        this.db.run('DELETE FROM user_voice_corrections WHERE id = ?', [id]);
      } catch (err) {
        console.warn('SQLite delete voice correction error:', err);
      }
    }
    try {
      localStorage.setItem(VOICE_CORRECTIONS_STORAGE_KEY, JSON.stringify(this.voiceCorrectionsCache));
    } catch {
      // Ignore
    }
    await this.persistEncrypted();
    return true;
  }

  private normalizeVoiceTranscript(text: string): string {
    if (!text) return '';
    return text
      .toLowerCase()
      .replace(/[\u064B-\u065F\u0670]/g, '') // remove Arabic/Urdu tashkeel
      .replace(/\u06be/g, 'ہ')
      .replace(/\u06d2/g, 'ی')
      .replace(/[,.?!:;'"()[\]{}_-]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // ============================================================================
  // SCREEN 4: SELF-LEARNING DICTIONARY (HIVE / LOCAL STORAGE EQUIVALENT)
  // {"wrong": "19", "correct": "19000", "context": "19 hazar"}
  // Next time, check this dictionary first before parsing.
  // ============================================================================
  private selfLearningCache: SelfLearningItem[] = [];

  getSelfLearningItems(): SelfLearningItem[] {
    if (this.selfLearningCache.length === 0) {
      try {
        const stored = localStorage.getItem(SELF_LEARNING_STORAGE_KEY);
        if (stored) {
          this.selfLearningCache = JSON.parse(stored);
        }
      } catch {
        this.selfLearningCache = [];
      }
    }
    return [...this.selfLearningCache];
  }

  async saveSelfLearningItem(wrong: string, correct: string, context: string): Promise<SelfLearningItem> {
    const wrongClean = String(wrong || '').trim();
    const correctClean = String(correct || '').trim();
    const contextClean = String(context || '').trim();
    const nowIso = new Date().toISOString();

    let items = this.getSelfLearningItems();
    const existingIndex = items.findIndex(
      (item) =>
        item.context.toLowerCase() === contextClean.toLowerCase() ||
        (item.wrong.toLowerCase() === wrongClean.toLowerCase() && item.context.toLowerCase() === contextClean.toLowerCase())
    );

    let record: SelfLearningItem;
    if (existingIndex >= 0) {
      record = {
        ...items[existingIndex],
        wrong: wrongClean,
        correct: correctClean,
        context: contextClean,
        updatedAt: nowIso,
      };
      items[existingIndex] = record;
    } else {
      record = {
        id: `learn-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        wrong: wrongClean,
        correct: correctClean,
        context: contextClean,
        updatedAt: nowIso,
      };
      items = [record, ...items];
    }

    this.selfLearningCache = items;
    try {
      localStorage.setItem(SELF_LEARNING_STORAGE_KEY, JSON.stringify(items));
    } catch {
      // Ignore
    }

    // Also sync with user voice corrections cache
    const correctNum = parseFloat(correctClean);
    if (!isNaN(correctNum) && correctNum > 0) {
      try {
        await this.saveUserVoiceCorrection(contextClean || wrongClean, correctNum);
      } catch {
        // Ignore
      }
    }

    // Reactive event dispatch
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('self_learning_dictionary_updated', { detail: record }));
    }

    return record;
  }

  findSelfLearningCorrection(text: string): SelfLearningItem | null {
    if (!text || !text.trim()) return null;
    const clean = text.trim().toLowerCase();
    const items = this.getSelfLearningItems();

    // 1. Exact match on context or wrong
    const exact = items.find(
      (item) =>
        item.context.toLowerCase() === clean ||
        item.wrong.toLowerCase() === clean
    );
    if (exact) return exact;

    // 2. Substring / Token match
    for (const item of items) {
      const ctx = item.context.toLowerCase();
      if (ctx.length >= 3 && (clean.includes(ctx) || ctx.includes(clean))) {
        return item;
      }
    }

    return null;
  }

  async deleteSelfLearningItem(id: string): Promise<boolean> {
    this.selfLearningCache = this.selfLearningCache.filter((item) => item.id !== id);
    try {
      localStorage.setItem(SELF_LEARNING_STORAGE_KEY, JSON.stringify(this.selfLearningCache));
    } catch {
      // Ignore
    }
    return true;
  }

  async clearSelfLearningItems(): Promise<boolean> {
    this.selfLearningCache = [];
    try {
      localStorage.removeItem(SELF_LEARNING_STORAGE_KEY);
    } catch {
      // Ignore
    }
    return true;
  }

  // Export raw SQLite binary file if db was loaded
  exportRawSQLite(): Uint8Array | null {
    if (this.db) {
      return this.db.export();
    }
    return null;
  }
}

export const dbService = new LocalDatabase();
