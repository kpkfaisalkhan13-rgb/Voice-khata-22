export type Language = 'en' | 'ur' | 'hi' | 'ru';

export interface Translations {
  appName: string;
  appSubtitle: string;
  shopDefaultName: string;
  totalReceive: string;
  totalGive: string;
  netBalance: string;
  totalToReceiveSubtitle: string;
  totalToGiveSubtitle: string;
  currencyUnit: string;
  searchPlaceholder: string;
  filterAll: string;
  filterReceive: string;
  filterGive: string;
  filterAlerts: string;
  addCustomer: string;
  quickVoiceKhata: string;
  voiceKhataSubtitle: string;
  tryVoiceBtn: string;
  noCustomersFound: string;
  noCustomersSubtext: string;
  debtAlertBannerTitle: string;
  debtAlertBannerCustomerExceeded: string;
  viewAlertList: string;
  exceededLimitBadge: string;
  owesMerchantBadge: string;
  merchantOwesBadge: string;
  settledBadge: string;
  customerTransactionsCount: string;

  // Main Tabs
  tabKhata: string;
  tabVoiceCalc: string;
  tabAnalytics: string;

  // Adapted Terms
  creditTerm: string;
  debitTerm: string;

  // Onboarding & Country Selection
  onboardingTitle: string;
  onboardingSubtitle: string;
  selectLanguage: string;
  selectCountry: string;
  countryPakistan: string;
  countryIndia: string;
  countryUSA: string;
  businessNameLabel: string;
  businessNamePlaceholder: string;
  getStarted: string;

  // Monetization & Trial
  freeTrialBanner: string;
  uploadScreenshot: string;
  tempAccessGranted: string;
  trialDaysLeft: string;
  paidFeaturesNote: string;

  // Voice Modal & Calculator
  voiceModalTitle: string;
  voiceModalSubtitle: string;
  voiceModalListening: string;
  voiceModalIdle: string;
  voiceModalHoldToSpeak: string;
  voiceModalProcessing: string;
  voiceModalNoSpeechDetected: string;
  voiceModalSpokenText: string;
  voiceModalCustomerFound: string;
  voiceModalCustomerNotFound: string;
  voiceModalBlockedTitle: string;
  voiceModalBlockedDesc: string;
  voiceModalConfirmSave: string;
  voiceModalCreateCustomer: string;
  voiceModalCancel: string;
  voiceModalTryAgain: string;
  voiceModalManualEntry: string;
  voiceModalManualPlaceholder: string;
  voiceModalCheckText: string;
  voiceModalCustomerLabel: string;
  voiceModalAmountLabel: string;
  voiceModalTypeLabel: string;
  voiceModalDebitType: string;
  voiceModalCreditType: string;
  voiceModalTestPhrasesTitle: string;
  voiceModalGroqActive: string;
  voiceSearchIntentTitle: string;
  voiceOpenLedger: string;
  voiceMultiEntriesFound: string;
  voiceSaveAllValid: string;
  voiceCalculatorTitle: string;
  voiceCalculationResult: string;
  voiceExpression: string;
  voiceUseInLedger: string;
  voiceCopyResult: string;
  voiceAccountMerged: string;
  voiceAccountMergedDesc: string;

  // Language selector
  langEnglish: string;
  langUrdu: string;
  langHindi: string;
  langRomanUrdu: string;

  // FAB
  voiceFabLabel: string;

  // Common actions
  save: string;
  cancel: string;
  delete: string;
  edit: string;
  exportPdf: string;
  pdfLedger: string;
  lockApp: string;
  analytics: string;
  settings: string;
  close: string;
  shareWhatsApp: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: 'Voice Ledger',
    appSubtitle: 'Voice Udhaar & Smart Ledger',
    shopDefaultName: 'My Ledger',
    totalReceive: 'You Will Receive',
    totalGive: 'You Will Give',
    netBalance: 'Net Balance',
    totalToReceiveSubtitle: 'Customer credit to be collected',
    totalToGiveSubtitle: 'Advance payments or supplier debt',
    currencyUnit: 'PKR',
    searchPlaceholder: 'Search customer name, phone, address...',
    filterAll: 'All Accounts',
    filterReceive: 'Credit (Got)',
    filterGive: 'Debit (Gave)',
    filterAlerts: 'Debt Limit Alerts',
    addCustomer: 'Add Customer',
    quickVoiceKhata: 'Voice Ledger (Speech-to-Text)',
    voiceKhataSubtitle: 'Tap mic and speak transaction naturally in Urdu, Hindi or English',
    tryVoiceBtn: 'Voice Khata',
    noCustomersFound: 'No customers match your search',
    noCustomersSubtext: 'Try searching another name or create a new customer',
    debtAlertBannerTitle: '⚠️ Customer Debt Limit Exceeded Alert',
    debtAlertBannerCustomerExceeded: 'The following customer has exceeded their maximum allowed debt limit:',
    viewAlertList: 'View Alert List',
    exceededLimitBadge: 'Limit Exceeded',
    owesMerchantBadge: 'Credit / Got',
    merchantOwesBadge: 'Debit / Gave',
    settledBadge: 'Settled',
    customerTransactionsCount: 'entries',

    // Main Tabs
    tabKhata: 'Khata',
    tabVoiceCalc: 'Voice Calc',
    tabAnalytics: 'Analytics',

    // Terms
    creditTerm: 'Credit (Got)',
    debitTerm: 'Debit (Gave)',

    // Onboarding
    onboardingTitle: 'Welcome to Voice Ledger',
    onboardingSubtitle: 'Instant voice-driven ledger with positional arithmetic calculation',
    selectLanguage: 'Choose Language',
    selectCountry: 'Select Your Country',
    countryPakistan: 'Pakistan (Rs. 100/mo)',
    countryIndia: 'India (₹100/mo)',
    countryUSA: 'USA / International ($5/mo)',
    businessNameLabel: 'Business / Shop Name',
    businessNamePlaceholder: 'e.g. My Ledger / میرا کھاتہ',
    getStarted: 'Open Dashboard Directly',

    // Monetization & Trial
    freeTrialBanner: '1-Month Free Trial Active (All features unlocked)',
    uploadScreenshot: 'Upload Payment Receipt',
    tempAccessGranted: '24-Hour Temporary Access Granted! Admin verification in progress.',
    trialDaysLeft: 'days remaining',
    paidFeaturesNote: 'Basic manual ledger & Voice Calculator are 100% free forever. Analytics & PDF export are included in the 1-month trial.',

    // Voice Modal
    voiceModalTitle: 'Record Transaction by Voice',
    voiceModalSubtitle: 'Tap the microphone to speak your transaction command',
    voiceModalListening: 'Listening... (Speak now)',
    voiceModalIdle: 'Tap microphone to speak',
    voiceModalHoldToSpeak: 'Tap or hold mic button to speak, release when finished',
    voiceModalProcessing: 'Transcribing speech & analyzing...',
    voiceModalNoSpeechDetected: 'No speech recognized. Please click the mic and speak clearly.',
    voiceModalSpokenText: 'Recognized Voice Input:',
    voiceModalCustomerFound: 'Customer Found in Ledger',
    voiceModalCustomerNotFound: 'Customer Not Found (Blocked)',
    voiceModalBlockedTitle: 'Customer Not in Ledger — Entry Blocked',
    voiceModalBlockedDesc: 'No registered customer found for this name. Please create a new customer first to record transactions.',
    voiceModalConfirmSave: 'Confirm & Save to Ledger',
    voiceModalCreateCustomer: 'Create New Customer Account',
    voiceModalCancel: 'Cancel',
    voiceModalTryAgain: 'Try Again',
    voiceModalManualEntry: 'Manual Entry (Type text)',
    voiceModalManualPlaceholder: 'e.g., Ali udhaar 5000 or Ali gave 2000',
    voiceModalCheckText: 'Analyze Text',
    voiceModalCustomerLabel: 'Customer Name',
    voiceModalAmountLabel: 'Amount',
    voiceModalTypeLabel: 'Transaction Type',
    voiceModalDebitType: 'Given on Credit (Debit)',
    voiceModalCreditType: 'Cash Received (Credit)',
    voiceModalTestPhrasesTitle: 'Quick Verification Phrases:',
    voiceModalGroqActive: 'Multilingual Whisper & Gemini Active',
    voiceSearchIntentTitle: 'Account Search & Balance Query',
    voiceOpenLedger: 'Open Account Ledger',
    voiceMultiEntriesFound: 'Entries Extracted',
    voiceSaveAllValid: 'Save All Valid Entries',
    voiceCalculatorTitle: 'Voice Calculator',
    voiceCalculationResult: 'Calculation Result',
    voiceExpression: 'Expression',
    voiceUseInLedger: 'Use in Ledger Entry',
    voiceCopyResult: 'Copy Result',
    voiceAccountMerged: 'Existing Account Merged (No Duplicate)',
    voiceAccountMergedDesc: 'Matched existing customer. Transaction will be appended without creating a duplicate account.',

    // Language selector
    langEnglish: 'English',
    langUrdu: 'اردو',
    langHindi: 'हिन्दी',
    langRomanUrdu: 'Roman Urdu',

    // FAB
    voiceFabLabel: 'Voice Khata',

    // Common actions
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    exportPdf: 'PDF & Reports',
    pdfLedger: 'PDF Ledger',
    lockApp: 'Lock App',
    analytics: 'Analytics',
    settings: 'Settings',
    close: 'Close',
    shareWhatsApp: 'Share via WhatsApp',
  },

  ur: {
    appName: 'وائس کھاتہ / وائس ادھار',
    appSubtitle: 'اسمارٹ ڈیجیٹل لیجر و صوتی کیلکولیٹر',
    shopDefaultName: 'میرا کھاتہ',
    totalReceive: 'آپ نے وصول کیے',
    totalGive: 'آپ نے قرض دیا',
    netBalance: 'خالص بیلنس',
    totalToReceiveSubtitle: 'گاہکوں کی طرف واجب الادا رقم',
    totalToGiveSubtitle: 'پیشگی یا سپلائر کے واجبات',
    currencyUnit: 'روپے',
    searchPlaceholder: 'گاہک کا نام، اردو نام، فون یا پتہ تلاش کریں...',
    filterAll: 'تمام کھاتے',
    filterReceive: 'وصول کیے',
    filterGive: 'قرض دیا',
    filterAlerts: 'حد الرٹ',
    addCustomer: 'نیا گاہک',
    quickVoiceKhata: 'آواز سے کھاتہ اندراج (وائس کھاتہ)',
    voiceKhataSubtitle: 'مائیک دبائیں اور عام انداز میں اردو میں کھاتہ بولیں',
    tryVoiceBtn: 'آواز آزمائیں',
    noCustomersFound: 'کوئی گاہک تلاش نہیں ہوا',
    noCustomersSubtext: 'کوئی دوسرا نام تلاش کریں یا نیا گاہک شامل کریں',
    debtAlertBannerTitle: '⚠️ قرض کی حد کا الرٹ (Debt Limit Exceeded)',
    debtAlertBannerCustomerExceeded: 'مندرجہ ذیل گاہک کا قرض مقررہ حد سے زیادہ ہو گیا ہے:',
    viewAlertList: 'الرٹ لسٹ دیکھیں',
    exceededLimitBadge: 'حد سے تجاوز',
    owesMerchantBadge: 'وصول کیے (آمدنی)',
    merchantOwesBadge: 'قرض دیا (خرچ)',
    settledBadge: 'برابر',
    customerTransactionsCount: 'اندراجات',

    // Main Tabs
    tabKhata: 'کھاتہ',
    tabVoiceCalc: 'وائس کیلکولیٹر',
    tabAnalytics: 'اینالیٹکس',

    // Terms
    creditTerm: 'وصول کیے',
    debitTerm: 'قرض دیا',

    // Onboarding
    onboardingTitle: 'وائس کھاتہ میں خوش آمدید',
    onboardingSubtitle: 'آواز سے چلنے والا فوری کھاتہ اور عددی کیلکولیٹر',
    selectLanguage: 'زبان منتخب کریں',
    selectCountry: 'اپنا ملک منتخب کریں',
    countryPakistan: 'پاکستان (100 روپے / ماہ)',
    countryIndia: 'بھارت (₹100 / ماہ)',
    countryUSA: 'امریکہ و بین الاقوامی ($5 / ماہ)',
    businessNameLabel: 'کاروبار / دکان کا نام',
    businessNamePlaceholder: 'مثال: میرا کھاتہ / My Ledger',
    getStarted: 'براہ راست ڈیش بورڈ کھولیں',

    // Monetization & Trial
    freeTrialBanner: '۱ ماہ فری ٹرائل فعال ہے (تمام فیچرز کھلے ہیں)',
    uploadScreenshot: 'ادائیگی کی رسید اپلوڈ کریں',
    tempAccessGranted: '۲۴ گھنٹے کی فوری عارضی رسائی منظور ہو گئی! دستی تصدیق جاری ہے۔',
    trialDaysLeft: 'دن باقی',
    paidFeaturesNote: 'بنیادی دستی کھاتہ اور صوتی کیلکولیٹر تاحیات مفت ہیں۔ تفصیلی رپورٹس و پی ڈی ایف ۱ ماہ کے ٹرائل میں شامل ہیں۔',

    // Voice Modal
    voiceModalTitle: 'بول کر کھاتے میں اندراج کریں',
    voiceModalSubtitle: 'بولنے کے لیے مائیک کا بٹن دبائیں',
    voiceModalListening: 'سن رہے ہیں... (اب بولیں)',
    voiceModalIdle: 'بولنے کے لیے مائیک پر کلک کریں',
    voiceModalHoldToSpeak: 'بولنے کے لیے مائیک دبائیں، ختم ہونے پر چھوڑیں',
    voiceModalProcessing: 'آواز کی شناخت اور تجزیہ جاری ہے...',
    voiceModalNoSpeechDetected: 'کوئی آواز سنائی نہیں دی۔ برائے مہربانی مائیک دبا کر صاف بولیں۔',
    voiceModalSpokenText: 'پہچانی گئی آواز:',
    voiceModalCustomerFound: 'گاہک کھاتے میں موجود ہے ✔️',
    voiceModalCustomerNotFound: 'گاہک کھاتے میں موجود نہیں ہے ❌',
    voiceModalBlockedTitle: 'یہ نام کھاتے میں موجود نہیں ہے - اندراج بلاک ہو گیا',
    voiceModalBlockedDesc: 'اس نام کا کوئی رجسٹرڈ گاہک نہیں ملا۔ اندراج کرنے کے لیے پہلے نیا کھاتہ کھولیں۔',
    voiceModalConfirmSave: 'کھاتے میں محفوظ کریں',
    voiceModalCreateCustomer: 'نیا کھاتہ بنائیں',
    voiceModalCancel: 'منسوخ کریں',
    voiceModalTryAgain: 'دوبارہ کوشش کریں',
    voiceModalManualEntry: 'خود لکھ کر درج کریں',
    voiceModalManualPlaceholder: 'مثال: علی کے کھاتے میں 5000 لکھ دو',
    voiceModalCheckText: 'تجزیہ کریں',
    voiceModalCustomerLabel: 'کسٹمر کا نام',
    voiceModalAmountLabel: 'رقم (روپے)',
    voiceModalTypeLabel: 'قسم',
    voiceModalDebitType: 'قرض دیا (DEBIT)',
    voiceModalCreditType: 'وصولی ہوئی (CREDIT)',
    voiceModalTestPhrasesTitle: 'فوری ٹیسٹ جملے:',
    voiceModalGroqActive: 'گروک وسپر و جیمنائی فعال',
    voiceSearchIntentTitle: 'اکاؤنٹ سرچ و بیلنس معلوم کریں',
    voiceOpenLedger: 'کھاتہ کھولیں',
    voiceMultiEntriesFound: 'اینٹریز موصول ہوئیں',
    voiceSaveAllValid: 'تمام درست اندراج محفوظ کریں',
    voiceCalculatorTitle: 'وائس کیلکولیٹر',
    voiceCalculationResult: 'حساب کا نتیجہ',
    voiceExpression: 'ریاضیاتی مساوات',
    voiceUseInLedger: 'کھاتے میں اینٹری کریں',
    voiceCopyResult: 'نتیجہ کاپی کریں',
    voiceAccountMerged: 'کھاتہ موجود ہے (ڈپلیکیٹ سے محفوظ)',
    voiceAccountMergedDesc: 'موجودہ کسٹمر کی شناخت ہوگئی۔ بغیر نیا کھاتہ کھولے رقم اس کھاتے میں جمع ہوگی۔',

    // Language selector
    langEnglish: 'English',
    langUrdu: 'اردو',
    langHindi: 'हिन्दी',
    langRomanUrdu: 'Roman Urdu',

    // FAB
    voiceFabLabel: 'آواز سے اندراج',

    // Common actions
    save: 'محفوظ کریں',
    cancel: 'منسوخ',
    delete: 'حذف کریں',
    edit: 'ترمیم',
    exportPdf: 'پی ڈی ایف رپورٹ',
    pdfLedger: 'پی ڈی ایف کھاتہ',
    lockApp: 'ایپ لاک کریں',
    analytics: 'اینالیٹکس و رپورٹس',
    settings: 'سیٹنگز',
    close: 'بند کریں',
    shareWhatsApp: 'واٹس ایپ پر بھیجیں',
  },

  hi: {
    appName: 'वॉयस लेजर / वॉयस उधार',
    appSubtitle: 'स्मार्ट डिजिटल खाता व वॉयस कैलकुलेटर',
    shopDefaultName: 'मेरा खाता',
    totalReceive: 'प्राप्त हुए (क्रेडिट)',
    totalGive: 'दिए (डेबिट)',
    netBalance: 'कुल बैलेंस',
    totalToReceiveSubtitle: 'ग्राहकों से लेने योग्य शेष राशि',
    totalToGiveSubtitle: 'अग्रिम भुगतान या सप्लायर को देय',
    currencyUnit: '₹',
    searchPlaceholder: 'ग्राहक का नाम, फोन या पता खोजें...',
    filterAll: 'सभी खाते',
    filterReceive: 'प्राप्त हुए',
    filterGive: 'दिए',
    filterAlerts: 'उधार सीमा अलर्ट',
    addCustomer: 'नया ग्राहक जोड़ें',
    quickVoiceKhata: 'वॉयस खाता (बोलकर एंट्री करें)',
    voiceKhataSubtitle: 'माइक दबाएं और हिंदी या अंग्रेजी में स्वाभाविक रूप से बोलें',
    tryVoiceBtn: 'वॉयस खाता',
    noCustomersFound: 'कोई ग्राहक नहीं मिला',
    noCustomersSubtext: 'कोई अन्य नाम खोजें या नया ग्राहक जोड़ें',
    debtAlertBannerTitle: '⚠️ ग्राहक उधार सीमा पार अलर्ट',
    debtAlertBannerCustomerExceeded: 'निम्नलिखित ग्राहक ने अपनी निर्धारित उधार सीमा पार कर ली है:',
    viewAlertList: 'अलर्ट सूची देखें',
    exceededLimitBadge: 'सीमा पार',
    owesMerchantBadge: 'प्राप्त हुए (क्रेडिट)',
    merchantOwesBadge: 'दिए (डेबिट)',
    settledBadge: 'बराबर',
    customerTransactionsCount: 'प्रविष्टियां',

    // Main Tabs
    tabKhata: 'खाता',
    tabVoiceCalc: 'वॉयस कैलकुलेटर',
    tabAnalytics: 'एनालिटिक्स',

    // Terms
    creditTerm: 'प्राप्त हुए',
    debitTerm: 'दिए',

    // Onboarding
    onboardingTitle: 'वॉयस लेजर में आपका स्वागत है',
    onboardingSubtitle: 'बोलकर लेन-देन दर्ज करें और तुरंत संख्यात्मक गणना करें',
    selectLanguage: 'भाषा चुनें',
    selectCountry: 'अपना देश चुनें',
    countryPakistan: 'पाकिस्तान (Rs. 100/माह)',
    countryIndia: 'भारत (₹100/माह)',
    countryUSA: 'यूएसए / अंतर्राष्ट्रीय ($5/माह)',
    businessNameLabel: 'व्यापार / दुकान का नाम',
    businessNamePlaceholder: 'उदा. मेरा खाता / My Ledger',
    getStarted: 'सीधे डैशबोर्ड खोलें',

    // Monetization & Trial
    freeTrialBanner: '1 माह का मुफ्त ट्रायल सक्रिय (सभी फीचर्स अनलॉक)',
    uploadScreenshot: 'पेमेंट स्क्रीनशॉट अपलोड करें',
    tempAccessGranted: '24 घंटे का अस्थायी एक्सेस स्वीकृत! व्यवस्थापक सत्यापन जारी है।',
    trialDaysLeft: 'दिन शेष',
    paidFeaturesNote: 'बुनियादी मैनुअल खाता और वॉयस कैलकुलेटर हमेशा के लिए 100% मुफ्त हैं। एनालिटिक्स और पीडीएफ 1 महीने के ट्रायल में शामिल हैं।',

    // Voice Modal
    voiceModalTitle: 'आवाज से लेन-देन दर्ज करें',
    voiceModalSubtitle: 'बोलने के लिए माइक बटन पर टैप करें',
    voiceModalListening: 'सुन रहे हैं... (अब बोलें)',
    voiceModalIdle: 'बोलने के लिए माइक दबाएं',
    voiceModalHoldToSpeak: 'बोलने के लिए माइक दबाएं, पूरा होने पर छोड़ें',
    voiceModalProcessing: 'आवाज की पहचान और विश्लेषण जारी है...',
    voiceModalNoSpeechDetected: 'कोई आवाज नहीं पहचानी गई। कृपया माइक दबाकर स्पष्ट बोलें।',
    voiceModalSpokenText: 'पहचानी गई आवाज:',
    voiceModalCustomerFound: 'ग्राहक खाते में मौजूद है ✔️',
    voiceModalCustomerNotFound: 'ग्राहक खाते में मौजूद नहीं है ❌',
    voiceModalBlockedTitle: 'यह नाम खाते में मौजूद नहीं है - एंट्री रोकी गई',
    voiceModalBlockedDesc: 'इस नाम का कोई पंजीकृत ग्राहक नहीं मिला। प्रविष्टि दर्ज करने के लिए पहले नया खाता बनाएं।',
    voiceModalConfirmSave: 'खाते में सुरक्षित करें',
    voiceModalCreateCustomer: 'नया ग्राहक बनाएं',
    voiceModalCancel: 'रद्द करें',
    voiceModalTryAgain: 'पुनः प्रयास करें',
    voiceModalManualEntry: 'मैन्युअल एंट्री (टाइप करें)',
    voiceModalManualPlaceholder: 'उदा: राहुल को 500 दिए या राहुल से 2000 प्राप्त हुए',
    voiceModalCheckText: 'विश्लेषण करें',
    voiceModalCustomerLabel: 'ग्राहक का नाम',
    voiceModalAmountLabel: 'राशि (₹)',
    voiceModalTypeLabel: 'लेन-देन का प्रकार',
    voiceModalDebitType: 'उधार दिया (डेबिट)',
    voiceModalCreditType: 'प्राप्त हुए (क्रेडिट)',
    voiceModalTestPhrasesTitle: 'त्वरित सत्यापन वाक्य:',
    voiceModalGroqActive: 'व्हिस्पर और जेमिनी सक्रिय',
    voiceSearchIntentTitle: 'खाता खोज व बैलेंस पूछताछ',
    voiceOpenLedger: 'खाता खोलें',
    voiceMultiEntriesFound: 'प्रविष्टियां प्राप्त हुईं',
    voiceSaveAllValid: 'सभी सही प्रविष्टियां सहेजें',
    voiceCalculatorTitle: 'वॉयस कैलकुलेटर',
    voiceCalculationResult: 'गणना का परिणाम',
    voiceExpression: 'गणितीय समीकरण',
    voiceUseInLedger: 'खाते में प्रविष्टि करें',
    voiceCopyResult: 'परिणाम कॉपी करें',
    voiceAccountMerged: 'मौजूदा खाता (कोई डुप्लिकेट नहीं)',
    voiceAccountMergedDesc: 'मौजूदा ग्राहक की पहचान हो गई। बिना नया खाता बनाए राशि इस खाते में जुड़ जाएगी।',

    // Language selector
    langEnglish: 'English',
    langUrdu: 'اردو',
    langHindi: 'हिन्दी',
    langRomanUrdu: 'Roman Urdu',

    // FAB
    voiceFabLabel: 'बोलकर लिखें',

    // Common actions
    save: 'सहेजें',
    cancel: 'रद्द करें',
    delete: 'हटाएं',
    edit: 'संपादित करें',
    exportPdf: 'पीडीएफ रिपोर्ट',
    pdfLedger: 'पीडीएफ खाता',
    lockApp: 'ऐप लॉक करें',
    analytics: 'एनालिटिक्स व रिपोर्ट',
    settings: 'सेटिंग्स',
    close: 'बंद करें',
    shareWhatsApp: 'व्हाट्सएप पर साझा करें',
  },

  ru: {
    appName: 'Voice Ledger',
    appSubtitle: 'Smart Digital Ledger & Voice Khata',
    shopDefaultName: 'Mera Khata',
    totalReceive: 'Maine Lene Hain',
    totalGive: 'Maine Dene Hain',
    netBalance: 'Net Balance',
    totalToReceiveSubtitle: 'Grahak ki taraf kul udhaar',
    totalToGiveSubtitle: 'Peshgi ya supplier k wajibaat',
    currencyUnit: 'PKR',
    searchPlaceholder: 'Customer name, phone ya address search karein...',
    filterAll: 'Tamam Khate',
    filterReceive: 'Lene Hain (Credit)',
    filterGive: 'Dene Hain (Debit)',
    filterAlerts: 'Debt Alerts',
    addCustomer: 'Naya Grahak',
    quickVoiceKhata: 'Awaz Se Khata (Voice Khata)',
    voiceKhataSubtitle: 'Mic dabayein aur Roman Urdu mein bole',
    tryVoiceBtn: 'Awaz Azmayein',
    noCustomersFound: 'Koi grahak nahi mila',
    noCustomersSubtext: 'Doosra naam talash karein ya naya grahak shamil karein',
    debtAlertBannerTitle: '⚠️ Udhaar Limit Exceeded Alert',
    debtAlertBannerCustomerExceeded: 'Is grahak ka udhaar limit se tajawuz kar gaya hai:',
    viewAlertList: 'Alert List Dekhein',
    exceededLimitBadge: 'Limit Exceeded',
    owesMerchantBadge: 'Lene Hain (Credit)',
    merchantOwesBadge: 'Dene Hain (Debit)',
    settledBadge: 'Barabar',
    customerTransactionsCount: 'entries',

    // Main Tabs
    tabKhata: 'Khata',
    tabVoiceCalc: 'Voice Calc',
    tabAnalytics: 'Analytics',

    // Terms
    creditTerm: 'Credit (Got)',
    debitTerm: 'Debit (Gave)',

    // Onboarding
    onboardingTitle: 'Voice Ledger Mein Khush Amdeed',
    onboardingSubtitle: 'Awaz se khata likhein aur foran hisab karein',
    selectLanguage: 'Zuban Select Karein',
    selectCountry: 'Mulk Select Karein',
    countryPakistan: 'Pakistan (Rs. 100/mo)',
    countryIndia: 'India (₹100/mo)',
    countryUSA: 'USA / International ($5/mo)',
    businessNameLabel: 'Dukan / Business Ka Naam',
    businessNamePlaceholder: 'Mera Khata / My Ledger',
    getStarted: 'Seedha Dashboard Kholein',

    // Monetization & Trial
    freeTrialBanner: '1 Mah Free Trial Active (Tamam features open)',
    uploadScreenshot: 'Payment Receipt Upload Karein',
    tempAccessGranted: '24 Ghante Ki Temporary Access Manzoor!',
    trialDaysLeft: 'din baqi',
    paidFeaturesNote: 'Manual ledger aur Voice Calculator hamesha ke liye free hain. Analytics aur PDF 1 month trial mein shamil hain.',

    // Voice Modal
    voiceModalTitle: 'Bol Kar Khate Mein Likhein',
    voiceModalSubtitle: 'Bolne ke liye mic ka button dabayein',
    voiceModalListening: 'Sun rahe hain... (Ab bolein)',
    voiceModalIdle: 'Bolne k liye mic dabayein',
    voiceModalHoldToSpeak: 'Bolne k liye mic dabayein, khatam hone par chhorein',
    voiceModalProcessing: 'Awaz samajh rahe hain...',
    voiceModalNoSpeechDetected: 'Koi awaz nahi suni gayi.',
    voiceModalSpokenText: 'Pehchani Gayi Awaz:',
    voiceModalCustomerFound: 'Grahak Khate Mein Maujood Hai ✔️',
    voiceModalCustomerNotFound: 'Grahak Khate Mein Nahi Mila ❌',
    voiceModalBlockedTitle: 'Ye Naam Khate Mein Nahi Hai - Entry Blocked',
    voiceModalBlockedDesc: 'Pehle is naam ka naya khata kholein.',
    voiceModalConfirmSave: 'Khate Mein Save Karein',
    voiceModalCreateCustomer: 'Naya Khata Banayein',
    voiceModalCancel: 'Cancel',
    voiceModalTryAgain: 'Dobara Koshish Karein',
    voiceModalManualEntry: 'Khud Likh Kar Enter Karein',
    voiceModalManualPlaceholder: 'e.g. Ali udhaar 5000',
    voiceModalCheckText: 'Analyze Karein',
    voiceModalCustomerLabel: 'Customer Name',
    voiceModalAmountLabel: 'Raqam (PKR)',
    voiceModalTypeLabel: 'Entry Type',
    voiceModalDebitType: 'Udhaar Diya (Debit)',
    voiceModalCreditType: 'Vasooli Hui (Credit)',
    voiceModalTestPhrasesTitle: 'Quick Test Sentences:',
    voiceModalGroqActive: 'Whisper & Gemini Active',
    voiceSearchIntentTitle: 'Account Search & Balance Query',
    voiceOpenLedger: 'Khata Kholein',
    voiceMultiEntriesFound: 'Entries Extracted',
    voiceSaveAllValid: 'Tamam Sahi Entries Save Karein',
    voiceCalculatorTitle: 'Voice Calculator',
    voiceCalculationResult: 'Calculation Ka Nateeja',
    voiceExpression: 'Math Expression',
    voiceUseInLedger: 'Khate Mein Entry Karein',
    voiceCopyResult: 'Copy Karein',
    voiceAccountMerged: 'Pehle Se Maujood Khata (No Duplicate)',
    voiceAccountMergedDesc: 'Purana customer pehchaan liya gaya. Duplicate khata banaye baghair entry jama hogi.',

    // Language selector
    langEnglish: 'English',
    langUrdu: 'اردو',
    langHindi: 'हिन्दी',
    langRomanUrdu: 'Roman Urdu',

    // FAB
    voiceFabLabel: 'Bol Kar Likhein',

    // Common actions
    save: 'Save Karein',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    exportPdf: 'PDF Report',
    pdfLedger: 'PDF Khata',
    lockApp: 'App Lock Karein',
    analytics: 'Analytics & Trends',
    settings: 'Settings',
    close: 'Band Karein',
    shareWhatsApp: 'WhatsApp Par Bhejein',
  },
};
